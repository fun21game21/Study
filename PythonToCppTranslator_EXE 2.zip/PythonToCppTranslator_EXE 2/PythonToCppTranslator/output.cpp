#include <cmath>
#include <iostream>
#include <set>
#include <vector>

using namespace std;


int main()
{
    int r = 0;
    vector<int> nums = {1, 2, 1};
    for (int i = 0; i < nums.size(); i++)
    {
        set<int> s;
        for (int j = i; j < nums.size(); j++)
        {
            s.insert(nums[j]);
            r += static_cast<int>(pow(s.size(), 2));
        }
    }
    cout << r << endl;
    return 0;
}
