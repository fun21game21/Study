# PyInstaller: один консольный Windows EXE, примеры включены как data resources.
from pathlib import Path

root = Path(SPECPATH)
a = Analysis(
    [str(root / 'main.py')],
    pathex=[str(root)],
    binaries=[],
    datas=[(str(root / 'examples'), 'examples')],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas,
    [('X utf8', None, 'OPTION')],
    name='PythonToCppTranslator',
    debug=False,
    strip=False,
    upx=False,
    console=True,
)
