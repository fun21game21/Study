@echo off
setlocal

pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto path_error

py -3 --version >nul 2>&1
if not errorlevel 1 goto use_py

python --version >nul 2>&1
if not errorlevel 1 goto use_python

goto python_error

:use_py
py -3 main.py
set "APP_EXIT=%ERRORLEVEL%"
goto finish

:use_python
python main.py
set "APP_EXIT=%ERRORLEVEL%"
goto finish

:path_error
echo Error
echo Cannot open the program folder.
set "APP_EXIT=1"
goto finish_no_popd

:python_error
echo Error
echo Python 3 was not found.
set "APP_EXIT=1"
goto finish

:finish
popd

:finish_no_popd
echo.
pause
exit /b %APP_EXIT%
