# Сборка Windows EXE

Только для разработчика. Пользователю готового EXE Python не нужен.

## Требования и команда

Windows и CPython x64 версии 3.9 или новее. Для выпущенного EXE использованы
CPython 3.13.13 x64 (официальный пакет python из NuGet) и PyInstaller 6.22.3.
Windows-хост сборки — Windows 11 ARM build 26200 в Parallels; x64 Python
и bootloader работали через системную эмуляцию. Итоговый PE Machine = 0x8664
(x86-64); это не ARM64 и не универсальный бинарный файл.

1. Откройте CMD в папке «Исходный код».
2. Выполните `build_windows.bat`.
3. Результат: `dist\PythonToCppTranslator.exe`. Скрипт также копирует EXE
   в родительскую пользовательскую папку.

Если Python не находится через `py -3-64` или `python`, задайте путь явно:

```bat
set "TRANSLATOR_PYTHON=C:\Path To Python\python.exe"
build_windows.bat
```

Скрипт проверяет архитектуру самого Python через sysconfig.get_platform(),
а не архитектуру ОС: это позволяет корректно работать с x64 Python на ARM.
Недостающий PyInstaller 6.22.3 устанавливается pip из requirements-build.txt.
Старые build/ и dist/ в папке исходников удаляются перед сборкой.
Для папки с UNC используется pushd только в developer-BAT; сам EXE CMD не вызывает.

Прямая эквивалентная команда:

```text
python -m PyInstaller --noconfirm --clean PythonToCppTranslator.spec
```

Режимы onefile и console определены в spec через EXE без COLLECT и console=True.
UPX отключён; hidden imports вручную не добавляются. Папка examples включается
как data resources, стандартные и локальные импорты анализируются PyInstaller.
`sys._MEIPASS` используется только для ресурсов. Внешние файлы — по
`Path(sys.executable).resolve().parent`. Нельзя собирать Windows PE на macOS.

## Проверка

- `python check_project.py`: 23 исходных проверки. При наличии clang++/g++
  компилирует все 11 программ C++17.
- `python check_frozen.py`: из этой папки на Windows при наличии EXE выше.
  Создаёт временные папки только с EXE/input, проверяет 11 пунктов, оба input,
  Error, отсутствующий input, неверные номера, одну паузу с ожиданием Enter.
  Проверяет отдельную рабочую директорию, убирает Python из PATH дочернего EXE.
  Если путь комплекта UNC, повторяет проверки в UNC-папке.
- При необходимости переменная TRANSLATOR_TEST_EXPORT задаёт каталог отчёта
  вне пользовательского комплекта. Там сохраняются frozen_report.json,
  фактический stdout и 11 generated C++ для проверки компилятором.

Для выпуска дополнительно выполнен тест без доступного частного сборочного
Python: каталог runtime временно переименован, запуск выполнен PowerShell,
PATH содержит только System32, рядом с EXE нет модулей или examples.
Все сценарии работают. Системный Python при этом не устанавливался.

Нативная Windows x64 отдельно не проверялась. Подпись Authenticode отсутствует.
В автоматизированном запуске приложения дополнительные окна не наблюдались;
поведение SmartScreen для загруженной копии на другом компьютере не проверено.

Официальная документация:
[PyInstaller spec/data files](https://pyinstaller.org/en/stable/spec-files.html),
[CPython NuGet для сборки](https://docs.python.org/3.13/using/windows.html#the-nuget-org-packages).
