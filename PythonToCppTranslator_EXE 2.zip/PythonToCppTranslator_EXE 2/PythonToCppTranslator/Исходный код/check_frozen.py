"""Windows smoke-test EXE. Нужен Python только разработчику, а не приложению.
Запуск: python check_frozen.py. Только EXE и два input в тестовых папках.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
from main import EXAMPLES, SUCCESS, ERROR, PAUSE
from translator import translate

ROOT = Path(__file__).resolve().parent
APPLICATION = ROOT.parent


def machine(path):
    data = path.read_bytes()
    assert data[:2] == b'MZ'
    offset = struct.unpack_from('<I', data, 0x3c)[0]
    assert data[offset:offset + 4] == b'PE\0\0'
    return struct.unpack_from('<H', data, offset + 4)[0]


def invoke(exe, answers, cwd):
    env = dict(os.environ)
    env['PATH'] = str(Path(os.environ['SystemRoot']) / 'System32')
    for key in ('PYTHONHOME', 'PYTHONPATH', 'VIRTUAL_ENV'):
        env.pop(key, None)
    result = subprocess.run([str(exe)], input=answers, text=True, encoding='utf-8',
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            cwd=cwd, env=env, timeout=45)
    assert result.returncode == 0, (result.returncode, result.stderr, result.stdout)
    assert not result.stderr and 'Traceback' not in result.stdout, result.stderr
    assert result.stdout.count(PAUSE) == 1, result.stdout
    return result.stdout


def check_folder(folder, export, label):
    folder.mkdir(parents=True)
    for name in ('PythonToCppTranslator.exe', 'input.py', 'input.txt'):
        shutil.copy2(APPLICATION / name, folder / name)
    assert len(list(folder.iterdir())) == 3
    exe = folder / 'PythonToCppTranslator.exe'
    with tempfile.TemporaryDirectory() as cwd:
        for index, (_, filename) in enumerate(EXAMPLES, 1):
            screen = invoke(exe, str(index) + '\n\n', cwd)
            assert SUCCESS in screen and ERROR not in screen
            expected = translate((ROOT / 'examples' / filename).read_text(encoding='utf-8-sig'))
            code = (folder / 'output.cpp').read_text(encoding='utf-8')
            assert code == (folder / 'output.txt').read_text(encoding='utf-8') == expected
            # Только временный каталог отчёта, не пользовательский комплект.
            (export / ('example_' + str(index) + '.cpp')).write_text(code, encoding='utf-8')
            if index == 9:
                (export / 'success.txt').write_text(screen, encoding='utf-8')
            print('OK', label, 'example', index, flush=True)
        for sub, name in [(1, 'input.py'), (2, 'input.txt')]:
            screen = invoke(exe, '12\n' + str(sub) + '\n\n', cwd)
            assert SUCCESS in screen
            expected = translate((folder / name).read_text(encoding='utf-8-sig'))
            assert (folder / 'output.cpp').read_text(encoding='utf-8') == expected
            assert (folder / 'output.cpp').read_bytes() == (folder / 'output.txt').read_bytes()
            if sub == 1:
                (export / 'input.txt').write_text(screen, encoding='utf-8')
        original = (folder / 'input.py').read_bytes()
        try:
            (folder / 'input.py').write_text('class Test:\n    pass\n', encoding='utf-8')
            screen = invoke(exe, '12\n1\n\n', cwd)
            assert ERROR + '\n\n' + PAUSE in screen and SUCCESS not in screen
            (folder / 'input.py').unlink()
            assert ERROR in invoke(exe, '12\n1\n\n', cwd)
        finally:
            (folder / 'input.py').write_bytes(original)
        screen = invoke(exe, 'bad\n12\n3\n2\n\n', cwd)
        assert screen.count('Некорректный выбор') == 2 and SUCCESS in screen
    return label + ': 11 examples, 2 input, Error, missing input, invalid menu; no source files; separate cwd; no Python in PATH'


def check_pause(exe):
    # Убедиться, что процесс действительно ждёт Enter после результата.
    process = subprocess.Popen([str(exe)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, encoding='utf-8')
    captured = []
    reached = threading.Event()
    def read():
        text = ''
        while True:
            char = process.stdout.read(1)
            if not char:
                return
            captured.append(char)
            text += char
            if text.endswith(PAUSE):
                reached.set()
    worker = threading.Thread(target=read, daemon=True)
    worker.start()
    try:
        process.stdin.write('1\n')
        process.stdin.flush()
        assert reached.wait(45), 'Final pause did not appear'
        assert process.poll() is None, 'Console closed before Enter'
        process.stdin.write('\n')
        process.stdin.flush()
        process.wait(timeout=15)
        worker.join(timeout=5)
        assert process.returncode == 0
        assert ''.join(captured).count(PAUSE) == 1
    finally:
        if process.poll() is None:
            process.kill()


def check():
    assert os.name == 'nt', 'Run frozen smoke tests on Windows'
    exe = APPLICATION / 'PythonToCppTranslator.exe'
    assert machine(exe) == 0x8664, 'Expected PE x86-64'
    # Каталог отчёта задаёт разработчик, по умолчанию находится вне комплекта.
    export = Path(os.environ.get('TRANSLATOR_TEST_EXPORT', tempfile.mkdtemp(prefix='translator-report-')))
    export.mkdir(parents=True, exist_ok=True)
    summaries = []
    with tempfile.TemporaryDirectory(prefix='Тест транслятора ') as d:
        folder = Path(d) / 'Лабораторная работа'
        summaries.append(check_folder(folder, export, 'local path with Cyrillic and spaces'))
        check_pause(folder / 'PythonToCppTranslator.exe')
    if str(APPLICATION).startswith('\\\\'):
        with tempfile.TemporaryDirectory(prefix='Тест UNC ', dir=APPLICATION.parent) as d:
            summaries.append(check_folder(Path(d) / 'Автономный комплект', export, 'UNC \\\\Mac\\Home'))
    report = {'architecture': 'x86-64', 'windows': sys.getwindowsversion().build,
              'sha256': hashlib.sha256(exe.read_bytes()).hexdigest(), 'checks': summaries,
              'pause': 'Exactly one; process stayed alive until Enter',
              'external_python': 'Child PATH contains only System32; no PYTHONHOME/PYTHONPATH'}
    (export / 'frozen_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    check()
