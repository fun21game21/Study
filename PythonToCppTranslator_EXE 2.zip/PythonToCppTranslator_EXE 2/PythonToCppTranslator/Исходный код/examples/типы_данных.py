a = 10
x = 3.14
text = "Python to C++"
flag = True
print(a, x, text, flag)
