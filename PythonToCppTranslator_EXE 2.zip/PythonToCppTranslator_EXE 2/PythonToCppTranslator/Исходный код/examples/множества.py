# Точный перебор M**N назначений. Для демонстрации: N <= 8, M <= 3.
n = int(input("Количество камней: "))
m = int(input("Количество куч: "))
if n < 1 or n > 8 or m < 1 or m > 3 or m > n:
    print("Нужно 1 <= M <= N <= 8 и M <= 3")
else:
    stones = []
    for i in range(n):
        w = int(input("Вес камня: "))
        stones.append(w)
    variants = m ** n
    best = -1
    best_code = 0
    for code in range(variants):
        sums = []
        counts = []
        for j in range(m):
            sums.append(0)
            counts.append(0)
        rest = code
        for i in range(n):
            pile = rest % m
            rest = rest // m
            sums[pile] += stones[i]
            counts[pile] += 1
        valid = True
        low = sums[0]
        high = sums[0]
        for j in range(m):
            if counts[j] == 0:
                valid = False
            if sums[j] < low:
                low = sums[j]
            if sums[j] > high:
                high = sums[j]
        difference = high - low
        if valid and (best == -1 or difference < best):
            best = difference
            best_code = code
    print("Минимальная разница:", best)
    assignment = []
    totals = []
    for j in range(m):
        totals.append(0)
    rest = best_code
    for i in range(n):
        pile = rest % m
        rest = rest // m
        assignment.append(pile + 1)
        totals[pile] += stones[i]
    print("Номера куч для камней:", assignment)
    print("Веса куч:", totals)
    # Простые операции с множествами.
    a = {1, 2, 3}
    b = {3, 4}
    print("Объединение:", a | b)
    print("Пересечение:", a & b)
    print("Разность:", a - b)
