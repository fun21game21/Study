from itertools import permutations

# Латинские буквы: перестановки C++ работают с однобайтовыми символами.
word = "stop"
words = ["stop", "post", "spot", "top", "pot", "so", "to"]
found = set()
for k in range(1, len(word) + 1):
    for p in permutations(word, k):
        candidate = "".join(p)
        if candidate in words and candidate not in found:
            found.add(candidate)
            print(candidate)
print("Найдено:", len(found))
