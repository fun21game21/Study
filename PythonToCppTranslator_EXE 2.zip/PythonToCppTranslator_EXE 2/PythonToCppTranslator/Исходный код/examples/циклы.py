total = 0
for i in range(1, 6):
    if i == 3:
        continue
    total += i
print(total)
for j in range(5, 0, -2):
    print(j)
n = 0
while n < 10:
    n += 1
    if n == 3:
        break
print(n)
