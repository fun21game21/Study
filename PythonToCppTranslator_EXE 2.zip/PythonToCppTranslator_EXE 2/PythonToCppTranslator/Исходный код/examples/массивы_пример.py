a = [1, 2, 3]
a[1] = 5
a.append(7)
print(a[0], len(a))
for x in a:
    print(x)
a.pop()
print(a)
