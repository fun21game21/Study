a = 10
b = 3
print(a + b, a - b, a * b)
print(a / b, a // b, a % b, a ** 2)
a += 2
a -= 1
a *= 2
x = 8.0
x /= 2
print(a, x)
