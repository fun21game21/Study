# Объём воды между стенами. Поиск максимумов обычными циклами.
a = [2, 5, 1, 2, 3, 4, 7, 7, 6, 1, 3, 9, 4, 3]
water = 0
for i in range(1, len(a) - 1):
    left = a[i]
    right = a[i]
    for j in range(0, i):
        if a[j] > left:
            left = a[j]
    for j in range(i + 1, len(a)):
        if a[j] > right:
            right = a[j]
    level = left
    if right < level:
        level = right
    water += level - a[i]
print(water)
