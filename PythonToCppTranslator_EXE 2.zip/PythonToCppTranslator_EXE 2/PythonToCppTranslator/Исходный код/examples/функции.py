def summa(a, b):
    return a + b

def show(x):
    print("Результат:", x)

result = summa(5, 3)
show(result)
