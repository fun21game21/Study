n = 7
if n < 0:
    print("Отрицательное")
elif n == 0:
    print("Ноль")
else:
    if n > 0 and not n == 10:
        print("Положительное, не десять")
