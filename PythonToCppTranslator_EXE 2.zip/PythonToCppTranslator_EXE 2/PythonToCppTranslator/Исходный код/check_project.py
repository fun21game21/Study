"""Небольшая регрессия: примеры, интерфейс и критические конструкции.
Запуск: python check_project.py. Компилятор C++17 необязателен.
Временные файлы создаются вне проекта; output восстанавливается.
"""
import itertools
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from translator import translate
from main import EXAMPLES, ERROR, SUCCESS, ROOT

COMPILER = shutil.which('clang++') or shutil.which('g++')


def run(command, text='', cwd=ROOT):
    return subprocess.run(command, input=text, text=True, encoding='utf-8',
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          cwd=cwd, timeout=60, check=True).stdout


def normalized(text):
    # Скобки/запятые коллекций, порядок простых int-множеств и точность
    # дробных cout-значений не являются частью требований лабораторной.
    words = re.sub(r'[\[\]{},]', ' ', text).split()
    # Учебный C++ выводит bool как 1/0.
    return [{'True': '1', 'False': '0'}.get(w, w) for w in words]


def equivalent(a, b):
    x, y = normalized(a), normalized(b)
    assert len(x) == len(y), (a, b)
    for u, v in zip(x, y):
        if u != v:
            assert abs(float(u) - float(v)) <= 1e-5 * max(1, abs(float(u))), (u, v)


def compiled(code, data, temp):
    source = temp / 'program.cpp'
    source.write_text(code, encoding='utf-8')
    binary = temp / 'program'
    run([COMPILER, '-std=c++17', '-Wall', '-Wextra', str(source), '-o', str(binary)])
    return run([str(binary)], data)


def check():
    count = 0
    saved = {n: (ROOT / n).read_bytes() if (ROOT / n).exists() else None
             for n in ('input.py', 'input.txt', 'output.cpp', 'output.txt')}
    try:
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            for i, (_, filename) in enumerate(EXAMPLES, 1):
                screen = run([sys.executable, str(ROOT / 'main.py')], str(i) + '\n', cwd=temp)
                assert SUCCESS in screen and ERROR not in screen, (filename, screen)
                code = (ROOT / 'output.cpp').read_text(encoding='utf-8')
                assert code == (ROOT / 'output.txt').read_text(encoding='utf-8')
                assert 'bits/stdc++.h' not in code
                assert all(word not in code for word in ('py_', 'runtime_error', '<stdexcept>'))
                if i == 5:
                    assert 'for (int i = 1; i < 6; i++)' in code
                    assert 'for (int j = 5; j > 0; j += -2)' in code
                if i == 6:
                    assert 'a[1] = 5;' in code and 'a.pop_back();' in code
                    assert 'for (int x : a)' in code
                if i == 9:
                    assert 'a[i]' in code and 'water += level - a[i];' in code
                data = 'Анна\n20\n1.7\n' if i == 2 else '4\n2\n1\n2\n3\n4\n' if i == 10 else ''
                python_output = run([sys.executable, str(ROOT / 'examples' / filename)], data)
                if COMPILER:
                    cpp_output = compiled(code, data, temp)
                    equivalent(python_output, cpp_output)
                    if i == 9:
                        assert cpp_output.strip() == '21'
                    if i == 10:
                        # Независимый эталон для маленького набора камней.
                        optimum = min(abs(sum(w for w, p in zip([1, 2, 3, 4], v) if p == 0) -
                                          sum(w for w, p in zip([1, 2, 3, 4], v) if p == 1))
                                      for v in itertools.product(range(2), repeat=4) if len(set(v)) == 2)
                        assert 'Минимальная разница: ' + str(optimum) in cpp_output
                count += 1
                print('OK', i, filename)
            for sub in (1, 2):
                screen = run([sys.executable, str(ROOT / 'main.py')], '12\n' + str(sub) + '\n', cwd=temp)
                assert SUCCESS in screen
                assert (ROOT / 'output.cpp').read_bytes() == (ROOT / 'output.txt').read_bytes()
                if COMPILER:
                    code = (ROOT / 'output.cpp').read_text(encoding='utf-8')
                    pyname = 'input.py' if sub == 1 else 'input.txt'
                    equivalent(run([sys.executable, str(ROOT / pyname)]), compiled(code, '', temp))
                count += 1
                print('OK input', sub)
            (ROOT / 'input.py').write_text('class Test:\n    pass\n', encoding='utf-8')
            screen = run([sys.executable, str(ROOT / 'main.py')], '12\n1\n')
            assert screen.endswith(ERROR + '\n') and 'Traceback' not in screen and SUCCESS not in screen
            count += 1
            # Ошибки выбора повторяют соответствующий запрос.
            screen = run([sys.executable, str(ROOT / 'main.py')], 'wrong\n0\n12\n3\n2\n')
            assert screen.count('Некорректный выбор') == 3 and SUCCESS in screen
            count += 1
            critical = [
                ('operators', 'a = 5\na = 8\nx = a / 2\nx /= 2\na %= 3\nprint(x, a, 1 < a <= 3)\n'),
                ('range', 'n = 5\ns = 0\ni = 99\nfor i in range(n):\n    n = 1\n    s += i\n    i = 10\nprint(s, i)\n'),
                ('sets', 'a = set()\na.add(1)\na.add(2)\na.remove(1)\nb = {2, 3}\nprint(a | b, a & b, b - a, 2 in a, 1 not in a)\nfor x in b:\n    print(x)\n'),
                ('empty_pop', 'print([1, 2])\na = []\na.append(4)\na.append(5)\na.pop()\nprint(a[0])\n'),
                ('full_permutations', 'from itertools import permutations\nword = "aba"\nfor p in permutations(word):\n    print("".join(p))\n'),
                ('float_function', 'def scale(x):\n    return x * 2.0\nprint(scale(1.5))\n'),
            ]
            for label, source in critical:
                code = translate(source)
                if COMPILER:
                    pyfile = temp / 'source.py'
                    pyfile.write_text(source, encoding='utf-8')
                    equivalent(run([sys.executable, str(pyfile)]), compiled(code, '', temp))
                count += 1
                print('OK', label)
            negatives = [
                'a = 1\na = "x"', 'a = []\na.append(1)\na.append("x")',
                'a = [[1]]', 'import os', 'a = [x for x in range(3)]',
                'def f(x=1):\n    return x\nprint(f())',
                'def f(n):\n    return g(n)\ndef g(n):\n    return f(n)\nprint(f(2))',
                'a = []', 'if False:\n    a = 2\nprint(a)',
                'for i in range(0, 2, 0):\n    print(i)', 'a =',
                'a = [1, 2]\nprint(a[-1])',
                'step = 2\nfor i in range(0, 4, step):\n    print(i)',
                'a = [1]\nx = a.pop()',
            ]
            for source in negatives:
                try:
                    translate(source)
                except Exception:
                    continue
                raise AssertionError('Unsupported source accepted: ' + source)
            count += 1
            print('OK rejection group:', len(negatives), 'cases')
            simple = translate('a = 5\nprint(a)\n')
            assert re.findall(r'#include <([^>]+)>', simple) == ['iostream']
            assert 'int a = 5;' in simple and 'cout << a << endl;' in simple
            literal = translate('print("text")\n')
            assert 'cout << "text" << endl;' in literal and '<string>' not in literal
            sets = translate('a = {1, 2}\nb = {2, 3}\nprint(a | b)\n')
            assert 'translator_set_union' in sets
            assert 'translator_set_intersection' not in sets and 'translator_set_difference' not in sets
            bat = (ROOT / 'build_windows.bat').read_text(encoding='utf-8')
            spec = (ROOT / 'PythonToCppTranslator.spec').read_text(encoding='utf-8')
            assert 'pushd "%~dp0"' in bat and '-m PyInstaller' in bat
            assert "console=True" in spec and "upx=False" in spec
            assert "'examples'" in spec and "'main.py'" in spec
            count += 1
            print('OK minimal headers and Windows build static check')
    finally:
        for name, data in saved.items():
            path = ROOT / name
            if data is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(data)
    print('PASS:', count, 'checks; C++17:', COMPILER or 'unavailable')


if __name__ == '__main__':
    check()
