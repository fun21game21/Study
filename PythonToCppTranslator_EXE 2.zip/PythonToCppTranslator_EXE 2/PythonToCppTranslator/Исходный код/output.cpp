#include <iostream>
#include <vector>

using namespace std;


int main()
{
    vector<int> a;
    for (int i = 1; i < 5; i++)
    {
        a.push_back(i * i);
    }
    cout << "Квадраты:" << " ";
    for (int translator_item1 : a)
    {
        cout << translator_item1 << " ";
    }
    cout << endl;
    return 0;
}
