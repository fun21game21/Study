@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" >nul 2>&1
if errorlevel 1 exit /b 1
set "BUILD_EXIT=1"
if defined TRANSLATOR_PYTHON goto custom_python
py -3-64 -c "import sys" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys" >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3 x64 is required for building. Set TRANSLATOR_PYTHON to python.exe.
goto finish
:custom_python
set PYTHON_CMD="%TRANSLATOR_PYTHON%"
goto check_python
:use_py
set "PYTHON_CMD=py -3-64"
goto check_python
:use_python
set "PYTHON_CMD=python"
:check_python
%PYTHON_CMD% -c "import sys,sysconfig; sys.exit(0 if sys.version_info >= (3,9) and sysconfig.get_platform() == 'win-amd64' else 1)"
if errorlevel 1 (
    echo Use x64 Python 3.9 or newer. ARM64 Python cannot build this x64 release.
    goto finish
)
%PYTHON_CMD% -c "import PyInstaller; assert PyInstaller.__version__ == '6.22.3'" >nul 2>&1
if not errorlevel 1 goto build
%PYTHON_CMD% -m pip install -r requirements-build.txt
if errorlevel 1 goto finish
:build
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
%PYTHON_CMD% -m PyInstaller --noconfirm --clean PythonToCppTranslator.spec
if errorlevel 1 goto finish
if not exist dist\PythonToCppTranslator.exe goto finish
copy /y dist\PythonToCppTranslator.exe ..\PythonToCppTranslator.exe >nul
if errorlevel 1 goto finish
echo Built dist\PythonToCppTranslator.exe and copied it to the application folder.
set "BUILD_EXIT=0"
:finish
popd
exit /b %BUILD_EXIT%
