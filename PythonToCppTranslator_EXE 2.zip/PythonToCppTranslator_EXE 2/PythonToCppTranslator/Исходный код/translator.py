"""Прямая генерация читаемого C++17 из проверенного Python AST."""
import ast
import json
from analyzer import analyze, collection, require, range_step
from parser import parse_source


def identifier(name):
    # Только реальные конфликты C++; обычные имена сохраняются.
    reserved = set(('alignas alignof and and_eq asm auto bitand bitor bool break case catch char '
                    'char16_t char32_t class compl const constexpr const_cast continue decltype '
                    'default delete do double dynamic_cast else enum explicit export extern false '
                    'float for friend goto if inline int long mutable namespace new noexcept not '
                    'not_eq nullptr operator or or_eq private protected public register '
                    'reinterpret_cast return short signed sizeof static static_assert static_cast '
                    'struct switch template this thread_local throw true try typedef typeid '
                    'typename union unsigned using virtual void volatile wchar_t while xor xor_eq '
                    'main cout cin endl string vector set pow find stoi stod').split())
    return name + '_value' if name in reserved or name.startswith('translator_') else name


def cpp_type(t, headers):
    if collection(t):
        headers.add(t[0])
        return t[0] + '<' + cpp_type(t[1], headers) + '>'
    if t == 'string':
        headers.add('string')
    return t


def translate(source):
    tree = parse_source(source)
    model = analyze(tree)
    names = set(model['env']) | set(model['functions'])
    for f in model['functions'].values():
        names.update(f['env'])
    require(len({identifier(n) for n in names}) == len(names))
    definite_assignment(model['main'], set())
    for f in model['functions'].values():
        definite_assignment(f['node'].body, {a.arg for a in f['node'].args.args})
    state = {'headers': set(), 'helpers': set(), 'counter': 0, 'model': model}
    functions = []
    prototypes = []
    for name, f in model['functions'].items():
        params = []
        for a, t in zip(f['node'].args.args, f['params']):
            params.append(cpp_type(t, state['headers']) + ('& ' if collection(t) else ' ') + identifier(a.arg))
        signature = cpp_type(f['return'], state['headers']) + ' ' + identifier(name) + '(' + ', '.join(params) + ')'
        prototypes.append(signature + ';')
        parameters = {a.arg for a in f['node'].args.args}
        functions.append(signature + '\n{\n' + block(f['node'].body, f['env'], state, 1, parameters) + '}\n')
    main = 'int main()\n{\n' + block(model['main'], model['env'], state, 1) + '    return 0;\n}\n'
    helpers = helper_code(state)
    includes = ''.join('#include <' + h + '>\n' for h in sorted(state['headers']))
    return includes + '\nusing namespace std;\n\n' + helpers + ('\n'.join(prototypes) + '\n\n' if prototypes else '') + '\n'.join(functions) + '\n' + main


def expr(n, env, s, parent=0):
    if isinstance(n, ast.Constant):
        if isinstance(n.value, str):
            return json.dumps(n.value, ensure_ascii=False)
        if isinstance(n.value, bool):
            return 'true' if n.value else 'false'
        return repr(n.value)
    if isinstance(n, ast.Name):
        return identifier(n.id)
    if isinstance(n, (ast.List, ast.Set)):
        t = n.inferred_type
        prefix = cpp_type(t, s['headers']) if t[1] is not None else ''
        return prefix + '{' + ', '.join(expr(x, env, s) for x in n.elts) + '}'
    if isinstance(n, ast.Subscript):
        return expr(n.value, env, s) + '[' + expr(n.slice, env, s) + ']'
    if isinstance(n, ast.BinOp):
        a, b = expr(n.left, env, s), expr(n.right, env, s)
        if collection(n.left.inferred_type):
            op = {ast.BitOr: 'union', ast.BitAnd: 'intersection', ast.Sub: 'difference'}[type(n.op)]
            s['helpers'].add('set_' + op)
            return 'translator_set_' + op + '(' + a + ', ' + b + ')'
        if isinstance(n.op, ast.Pow):
            s['headers'].add('cmath')
            return 'static_cast<' + n.inferred_type + '>(pow(' + a + ', ' + b + '))'
        if isinstance(n.op, ast.Div):
            a = expr(n.left, env, s, 6)
            if n.left.inferred_type == n.right.inferred_type == 'int':
                a = 'static_cast<double>(' + expr(n.left, env, s) + ')'
            text = a + ' / ' + expr(n.right, env, s, 7)
            return '(' + text + ')' if parent > 6 else text
        op = {ast.Add: '+', ast.Sub: '-', ast.Mult: '*', ast.FloorDiv: '/', ast.Mod: '%'}[type(n.op)]
        precedence = 5 if op in ('+', '-') else 6
        a = expr(n.left, env, s, precedence)
        b = expr(n.right, env, s, precedence + 1)
        if n.inferred_type == 'string' and isinstance(n.left, ast.Constant):
            s['headers'].add('string')
            a = 'string(' + a + ')'
        text = a + ' ' + op + ' ' + b
        return '(' + text + ')' if parent > precedence else text
    if isinstance(n, ast.UnaryOp):
        operator = {ast.Not: '!', ast.UAdd: '+', ast.USub: '-'}[type(n.op)]
        gap = ' ' if isinstance(n.operand, ast.UnaryOp) else ''
        return operator + gap + expr(n.operand, env, s, 7)
    if isinstance(n, ast.BoolOp):
        precedence = 2 if isinstance(n.op, ast.And) else 1
        text = (' && ' if isinstance(n.op, ast.And) else ' || ').join(expr(x, env, s, precedence) for x in n.values)
        return '(' + text + ')' if parent > precedence else text
    if isinstance(n, ast.Compare):
        parts = []
        for a, op, b in zip([n.left] + n.comparators, n.ops, n.comparators):
            if isinstance(op, (ast.In, ast.NotIn)):
                value, container = expr(a, env, s), expr(b, env, s)
                if b.inferred_type[0] == 'set':
                    part = container + '.count(' + value + ') ' + ('==' if isinstance(op, ast.NotIn) else '!=') + ' 0'
                elif not isinstance(b, ast.Name):
                    # Временный список нельзя трижды создавать для begin/end.
                    s['helpers'].add('contains')
                    part = ('!' if isinstance(op, ast.NotIn) else '') + 'translator_contains(' + container + ', ' + value + ')'
                else:
                    s['headers'].add('algorithm')
                    part = 'find(' + container + '.begin(), ' + container + '.end(), ' + value + ') ' + ('==' if isinstance(op, ast.NotIn) else '!=') + ' ' + container + '.end()'
                parts.append(part)
            else:
                operator = {ast.Eq: '==', ast.NotEq: '!=', ast.Lt: '<', ast.LtE: '<=', ast.Gt: '>', ast.GtE: '>='}[type(op)]
                # Литералы string в сравнении требуют сравнения значений, не адресов.
                left = expr(a, env, s, 5)
                if a.inferred_type == 'string' and isinstance(a, ast.Constant):
                    s['headers'].add('string')
                    left = 'string(' + left + ')'
                parts.append(left + ' ' + operator + ' ' + expr(b, env, s, 5))
        text = ' && '.join(parts)
        precedence = 2 if len(parts) > 1 else 3
        return '(' + text + ')' if parent > precedence else text
    if isinstance(n, ast.Call):
        args = [expr(a, env, s) for a in n.args]
        if isinstance(n.func, ast.Name):
            name = n.func.id
            if name == 'input':
                s['helpers'].add('input')
                return 'translator_input(' + (args[0] if args else '""') + ')'
            if name in ('int', 'float'):
                if n.args[0].inferred_type == 'string':
                    s['headers'].add('string')
                    return ('stoi' if name == 'int' else 'stod') + '(' + args[0] + ')'
                return 'static_cast<' + ('int' if name == 'int' else 'double') + '>(' + args[0] + ')'
            if name == 'len':
                value = args[0]
                if isinstance(n.args[0], ast.Constant):
                    s['headers'].add('string')
                    value = 'string(' + value + ')'
                text = value + '.size()'
                # В арифметике/сравнениях нужен знаковый int (например len(a)-1).
                return 'static_cast<int>(' + text + ')' if parent >= 5 else text
            if name == 'set':
                return '{}'
            return identifier(name) + '(' + ', '.join(args) + ')'
        if n.func.attr == 'join':
            return args[0]
        if n.func.attr == 'pop':
            return expr(n.func.value, env, s) + '.pop_back()'
    raise ValueError('Unsupported expression')


def assigned_names(nodes):
    return {x.id for n in nodes for x in ast.walk(n)
            if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Store)}


def loaded_names(nodes):
    return {x.id for n in nodes for x in ast.walk(n)
            if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Load)}


def needed_names(nodes):
    """Чтения до присваивания; имя нового for не требует внешнего объявления."""
    needed, assigned = set(), set()
    for n in nodes:
        if isinstance(n, ast.For):
            reads = loaded_names([n.iter]) | (needed_names(n.body) - {n.target.id})
        elif isinstance(n, (ast.If, ast.While)):
            reads = loaded_names([n.test]) | needed_names(n.body) | needed_names(n.orelse)
        elif isinstance(n, ast.Assign):
            reads = loaded_names([n.value])
            if isinstance(n.targets[0], ast.Subscript):
                reads |= loaded_names([n.targets[0]])
        else:
            reads = loaded_names([n])
            if isinstance(n, ast.AugAssign) and isinstance(n.target, ast.Name):
                reads.add(n.target.id)
        needed |= reads - assigned
        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name):
            assigned.add(n.targets[0].id)
    return needed


def temporary(s, label):
    s['counter'] += 1
    return 'translator_' + label + str(s['counter'])


def block(body, env, s, level, declared=None):
    result = []
    declared = set() if declared is None else declared.copy()
    indent = '    ' * level
    # После ветвления Python-переменная может быть нужна в общей C++ области.
    for pos, n in enumerate(body):
        if isinstance(n, (ast.If, ast.For, ast.While)):
            hoisted = assigned_names([n]) & needed_names(body[pos + 1:])
            for name in sorted(hoisted - declared):
                result.append(indent + cpp_type(env[name], s['headers']) + ' ' + identifier(name) + '{};\n')
                declared.add(name)
        line = ''
        if isinstance(n, ast.Assign):
            target = n.targets[0]
            prefix = ''
            fresh = isinstance(target, ast.Name) and target.id not in declared
            if fresh:
                prefix = cpp_type(env[target.id], s['headers']) + ' '
                declared.add(target.id)
            value = n.value
            input_call = value if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'input' else None
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id in ('int', 'float'):
                arg = value.args[0]
                if isinstance(arg, ast.Call) and isinstance(arg.func, ast.Name) and arg.func.id == 'input':
                    input_call = arg
            target_text = expr(target, env, s)
            if input_call is not None:
                s['headers'].add('iostream')
                if fresh:
                    result.append(indent + prefix + target_text + ';\n')
                if input_call.args:
                    result.append(indent + 'cout << ' + expr(input_call.args[0], env, s) + ';\n')
                line = 'cin >> ' + target_text + ';'
            else:
                if isinstance(value, (ast.List, ast.Set)):
                    rhs = '{' + ', '.join(expr(x, env, s) for x in value.elts) + '}'
                elif isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'set':
                    rhs = '{}'
                else:
                    rhs = expr(value, env, s)
                if fresh and rhs == '{}':
                    line = prefix + target_text + ';'
                else:
                    line = prefix + target_text + ' = ' + rhs + ';'
        elif isinstance(n, ast.AugAssign):
            operators = {ast.Add: '+=', ast.Sub: '-=', ast.Mult: '*=', ast.Div: '/=', ast.Mod: '%='}
            if type(n.op) in operators and not collection(n.target.inferred_type):
                line = expr(n.target, env, s) + ' ' + operators[type(n.op)] + ' ' + expr(n.value, env, s) + ';'
            else:
                line = expr(n.target, env, s) + ' = ' + expr(n.calculation, env, s) + ';'
        elif isinstance(n, ast.Expr):
            c = n.value
            if isinstance(c.func, ast.Name) and c.func.id == 'print':
                s['headers'].add('iostream')
                stream = []
                for i, a in enumerate(c.args):
                    if i:
                        stream.append('" "')
                    t = env[a.id] if isinstance(a, ast.Name) else a.inferred_type
                    if collection(t):
                        if stream:
                            result.append(indent + 'cout << ' + ' << '.join(stream) + ';\n')
                            stream = []
                        item = temporary(s, 'item')
                        result.append(indent + 'for (' + cpp_type(t[1], s['headers']) + ' ' + item + ' : ' + expr(a, env, s) + ')\n' + indent + '{\n' + indent + '    cout << ' + item + ' << " ";\n' + indent + '}\n')
                    else:
                        stream.append(expr(a, env, s, 4))
                stream.append('endl')
                line = 'cout << ' + ' << '.join(stream) + ';'
            elif isinstance(c.func, ast.Attribute) and c.func.attr in ('append', 'add', 'remove'):
                method = {'append': 'push_back', 'add': 'insert', 'remove': 'erase'}[c.func.attr]
                line = expr(c.func.value, env, s) + '.' + method + '(' + expr(c.args[0], env, s) + ');'
            else:
                line = expr(c, env, s) + ';'
        elif isinstance(n, ast.If):
            line = 'if (' + expr(n.test, env, s) + ')\n' + indent + '{\n' + block(n.body, env, s, level + 1, declared) + indent + '}'
            if len(n.orelse) == 1 and isinstance(n.orelse[0], ast.If):
                line += '\n' + indent + 'else ' + block(n.orelse, env, s, level, declared).lstrip().rstrip()
            elif n.orelse:
                line += '\n' + indent + 'else\n' + indent + '{\n' + block(n.orelse, env, s, level + 1, declared) + indent + '}'
        elif isinstance(n, ast.While):
            line = 'while (' + expr(n.test, env, s) + ')\n' + indent + '{\n' + block(n.body, env, s, level + 1, declared) + indent + '}'
        elif isinstance(n, ast.For):
            it = n.iter
            target = identifier(n.target.id)
            inner_declared = declared | {n.target.id}
            inside = ''
            if isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'range':
                args = [expr(a, env, s) for a in it.args]
                start, end = ('0', args[0]) if len(args) == 1 else (args[0], args[1])
                step = range_step(it)
                # Только если тело меняет границу, сохраняем её исходное значение.
                changed = assigned_names(n.body)
                for child in ast.walk(n):
                    if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and isinstance(child.func.value, ast.Name):
                        changed.add(child.func.value.id)
                bounds = [ast.Constant(value=0), it.args[0]] if len(it.args) == 1 else it.args[:2]
                for k, bound in enumerate(bounds):
                    if loaded_names([bound]) & changed or any(isinstance(x, ast.Call) and not (isinstance(x.func, ast.Name) and x.func.id == 'len') for x in ast.walk(bound)):
                        name = temporary(s, 'bound')
                        text = start if k == 0 else end
                        result.append(indent + 'const int ' + name + ' = ' + text + ';\n')
                        if k == 0:
                            start = name
                        else:
                            end = name
                index = target
                prefix = 'int ' if n.target.id not in declared else ''
                # Редкий случай: запись в i внутри тела или чтение прежней i
                # после цикла. Обычные циклы используют исходное имя прямо в for.
                if n.target.id in changed or n.target.id in declared and n.target.id in needed_names(body[pos + 1:]):
                    index = temporary(s, 'index')
                    prefix = 'int '
                    inside = indent + '    ' + ('' if n.target.id in declared else 'int ') + target + ' = ' + index + ';\n'
                update = index + ('++' if step == 1 else '--' if step == -1 else ' += ' + str(step))
                header = 'for (' + prefix + index + ' = ' + start + '; ' + index + (' < ' if step > 0 else ' > ') + end + '; ' + update + ')'
            else:
                if isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'permutations':
                    s['helpers'].add('permutations')
                    a = expr(it.args[0], env, s)
                    if isinstance(it.args[0], ast.Constant):
                        s['headers'].add('string')
                        a = 'string(' + a + ')'
                    k = expr(it.args[1], env, s) if len(it.args) == 2 else 'static_cast<int>(' + a + '.size())'
                    iterable = 'translator_permutations(' + a + ', ' + k + ')'
                else:
                    iterable = expr(it, env, s)
                item = target if n.target.id not in declared else temporary(s, 'item')
                if item != target:
                    inside = indent + '    ' + target + ' = ' + item + ';\n'
                header = 'for (' + cpp_type(env[n.target.id], s['headers']) + ' ' + item + ' : ' + iterable + ')'
            line = header + '\n' + indent + '{\n' + inside + block(n.body, env, s, level + 1, inner_declared) + indent + '}'
        elif isinstance(n, ast.Return):
            line = 'return' + (' ' + expr(n.value, env, s) if n.value else '') + ';'
        elif isinstance(n, (ast.Break, ast.Continue)):
            line = 'break;' if isinstance(n, ast.Break) else 'continue;'
        else:
            raise ValueError('Unsupported statement')
        result.append(indent + line + '\n')
    return ''.join(result)


def definite_assignment(body, assigned):
    """Не пропускаем чтение переменной, заданной лишь в одной ветке/итерации."""
    assigned = assigned.copy()
    def reads(node):
        for x in ast.walk(node):
            if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Load):
                # Имя вызываемой функции не является переменной.
                if x.id not in assigned:
                    require(any(isinstance(c, ast.Call) and c.func is x for c in ast.walk(node)))
    for n in body:
        if isinstance(n, ast.AugAssign):
            reads(n.value)
            if isinstance(n.target, ast.Name):
                require(n.target.id in assigned)
            else:
                reads(n.target)
        elif isinstance(n, ast.Assign):
            reads(n.value)
            if isinstance(n.targets[0], ast.Name):
                assigned.add(n.targets[0].id)
            else:
                reads(n.targets[0])
        elif isinstance(n, ast.If):
            reads(n.test)
            a = definite_assignment(n.body, assigned)
            b = definite_assignment(n.orelse, assigned)
            # Если одна ветка завершается return, доступность задаёт другая.
            if any(isinstance(x, ast.Return) for x in n.body):
                assigned = b
            elif any(isinstance(x, ast.Return) for x in n.orelse):
                assigned = a
            else:
                assigned = a & b
        elif isinstance(n, ast.For):
            reads(n.iter)
            definite_assignment(n.body, assigned | {n.target.id})
        elif isinstance(n, ast.While):
            reads(n.test)
            definite_assignment(n.body, assigned)
        else:
            reads(n)
    return assigned


def helper_code(s):
    h = s['headers']
    code = []
    if 'contains' in s['helpers']:
        code.append('''template<class Container, class T>
bool translator_contains(const Container& values, const T& value)
{
    for (const auto& item : values)
        if (item == value) return true;
    return false;
}
''')
    if 'input' in s['helpers']:
        h.update({'iostream', 'string'})
        code.append('''string translator_input(const string& prompt)
{
    cout << prompt;
    string value;
    cin >> value;
    return value;
}
''')
    for operation in ('union', 'intersection', 'difference'):
        if 'set_' + operation not in s['helpers']:
            continue
        h.add('set')
        action = {'union': 'for (const T& x : b) result.insert(x);',
                  'intersection': 'for (const T& x : a) if (b.count(x)) result.insert(x);',
                  'difference': 'for (const T& x : a) if (!b.count(x)) result.insert(x);'}[operation]
        initial = ' = a' if operation == 'union' else ''
        code.append('template<class T>\nset<T> translator_set_' + operation + '(const set<T>& a, const set<T>& b)\n{\n    set<T> result' + initial + ';\n    ' + action + '\n    return result;\n}\n')
    if 'permutations' in s['helpers']:
        h.update({'vector', 'string'})
        code.append('''// Перебор позиций, как в itertools.permutations (повторения букв допустимы).
void translator_permute(const string& word, int k, string& current,
                vector<bool>& used, vector<string>& result)
{
    if (static_cast<int>(current.size()) == k)
    {
        result.push_back(current);
        return;
    }
    for (int i = 0; i < static_cast<int>(word.size()); ++i)
    {
        if (!used[i])
        {
            used[i] = true;
            current += word[i];
            translator_permute(word, k, current, used, result);
            current.pop_back();
            used[i] = false;
        }
    }
}
vector<string> translator_permutations(const string& word, int k)
{
    vector<string> result;
    if (k < 0 || k > static_cast<int>(word.size())) return result;
    vector<bool> used(word.size(), false);
    string current;
    translator_permute(word, k, current, used, result);
    return result;
}
''')
    return '\n'.join(code) + ('\n' if code else '')
