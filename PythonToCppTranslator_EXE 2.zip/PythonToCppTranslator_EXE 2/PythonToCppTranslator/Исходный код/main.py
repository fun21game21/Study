"""Консольный интерфейс; внешние файлы рядом с EXE, примеры внутри bundle."""
from pathlib import Path
import sys
from translator import translate


def get_application_dir():
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def get_resource_dir():
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))


ROOT = get_application_dir()
EXAMPLES = [
    ('Типы данных', 'типы_данных.py'),
    ('Ввод / вывод', 'ввод_вывод.py'),
    ('Вычисления', 'вычисления.py'),
    ('Ветвления', 'ветвления.py'),
    ('Циклы', 'циклы.py'),
    ('Массивы', 'массивы_пример.py'),
    ('Функции', 'функции.py'),
    ('Рекурсия', 'рекурсия.py'),
    ('Задача "Массивы"', 'массивы.py'),
    ('Задача "Множества"', 'множества.py'),
    ('Задача "Перестановки"', 'перестановки.py'),
]
ERROR = 'Error\nПроверьте корректность и выполняемость входного файла'
SUCCESS = 'Трансляция выполнена успешно.\n\nСозданы файлы:\noutput.cpp\noutput.txt'
PAUSE = 'Нажмите Enter для выхода...'


def choice(prompt, allowed):
    while True:
        answer = input(prompt).strip()
        if answer in allowed:
            return int(answer)
        print('Некорректный выбор')


def main():
    print('========================================\n       ТРАНСЛЯТОР PYTHON -> C++\n========================================\n')
    print('Выберите программу для трансляции:\n')
    for i, (label, _) in enumerate(EXAMPLES, 1):
        print(f'{i:2} - {label}')
    print('12 - Использовать файл input\n')
    try:
        number = choice('Ваш выбор: ', {str(i) for i in range(1, 13)})
        if number == 12:
            print('\nВыберите исходный файл:\n\n1 - input.py\n2 - input.txt\n')
            sub = choice('Ваш выбор: ', {'1', '2'})
            source_path = ROOT / ('input.py' if sub == 1 else 'input.txt')
        else:
            source_path = get_resource_dir() / 'examples' / EXAMPLES[number - 1][1]
        code = translate(source_path.read_text(encoding='utf-8-sig'))
        for name in ('output.cpp', 'output.txt'):
            (ROOT / name).write_text(code, encoding='utf-8')
        print('\n' + SUCCESS)
    except Exception:
        print('\n' + ERROR)
    finally:
        if getattr(sys, 'frozen', False):
            try:
                input('\n' + PAUSE)
            except EOFError:
                pass


if __name__ == '__main__':
    if sys.platform == 'win32':
        for stream in (sys.stdin, sys.stdout, sys.stderr):
            if hasattr(stream, 'reconfigure'):
                stream.reconfigure(encoding='utf-8')
    main()
