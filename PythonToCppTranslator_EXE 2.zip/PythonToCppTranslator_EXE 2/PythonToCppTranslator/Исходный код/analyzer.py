"""Проверка учебного подмножества AST и простые таблицы типов.

Тип — строка int/double/string/bool/void либо пара (vector/set, тип элемента).
Параметры функций определяются по вызову. Прямая рекурсия использует тип
простого базового return. Разные типы при повторных вызовах запрещены.
"""
import ast

SCALARS = {'int', 'double', 'string', 'bool'}
NUMBERS = {'int', 'double'}


def require(condition):
    if not condition:
        raise ValueError('Unsupported Python or incompatible types')


def collection(t):
    return isinstance(t, tuple) and t[0] in ('vector', 'set')


def range_step(call):
    """В учебном range шаг — только ненулевая целая константа."""
    if len(call.args) < 3:
        return 1
    node = call.args[2]
    sign = 1
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        sign = -1 if isinstance(node.op, ast.USub) else 1
        node = node.operand
    require(isinstance(node, ast.Constant) and type(node.value) is int and node.value != 0)
    return sign * node.value


def compatible(a, b):
    return a == b


def merge_collection(a, b):
    if collection(a) and collection(b) and a[0] == b[0]:
        if a[1] is None:
            return b
        if b[1] is None:
            return a
    require(a == b)
    return a


def analyze(tree):
    functions = {}
    main = []
    imported = False
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            require(node.module == 'itertools' and node.level == 0 and
                    len(node.names) == 1 and node.names[0].name == 'permutations' and
                    node.names[0].asname is None and not imported)
            imported = True
        elif isinstance(node, ast.FunctionDef):
            require(node.name not in functions and not node.decorator_list and
                    not node.args.defaults and not node.args.kw_defaults and
                    not node.args.kwonlyargs and not node.args.posonlyargs and
                    node.args.vararg is None and node.args.kwarg is None and
                    node.returns is None and all(a.annotation is None for a in node.args.args))
            functions[node.name] = {'node': node, 'params': None, 'return': None,
                                    'env': {}, 'active': False}
        else:
            main.append(node)
    model = {'functions': functions, 'env': {}, 'main': main, 'imported': imported,
             'stack': []}
    check_block(main, model['env'], model, None, 0)
    for f in functions.values():
        # Для невызванных функций учебная версия требует явного демонстрационного вызова.
        require(f['params'] is not None)
    for env in [model['env']] + [f['env'] for f in functions.values()]:
        require(all(not collection(t) or t[1] in SCALARS for t in env.values()))
    return model


def function_call(name, types, model):
    f = model['functions'][name]
    require(len(types) == len(f['node'].args.args) and all(t != 'void' for t in types))
    if f['params'] is not None:
        require(types == f['params'])
        if f['active']:
            require(model['stack'][-1] == name and f['return'] is not None)
        return f['return']
    f['params'] = types
    f['env'] = dict(zip((a.arg for a in f['node'].args.args), types))
    f['active'] = True
    model['stack'].append(name)
    # Простая опора для прямой рекурсии: известный базовый return.
    returns = [n for n in ast.walk(f['node']) if isinstance(n, ast.Return)]
    for n in returns:
        if n.value is not None and not any(isinstance(x, ast.Call) and
                isinstance(x.func, ast.Name) and x.func.id in model['functions']
                for x in ast.walk(n.value)):
            try:
                f['return'] = expression_type(n.value, f['env'], model)
                break
            except (ValueError, KeyError):
                pass
    check_block(f['node'].body, f['env'], model, f, 0)
    if f['return'] is None:
        f['return'] = 'void'
    if f['return'] != 'void':
        require(always_returns(f['node'].body))
    model['stack'].pop()
    f['active'] = False
    return f['return']


def always_returns(body):
    for n in body:
        if isinstance(n, ast.Return):
            return True
        if isinstance(n, ast.If) and n.orelse and always_returns(n.body) and always_returns(n.orelse):
            return True
    return False


def expression_type(n, env, model):
    t = None
    if isinstance(n, ast.Constant):
        t = {int: 'int', float: 'double', str: 'string', bool: 'bool'}.get(type(n.value))
        require(t is not None)
    elif isinstance(n, ast.Name):
        require(n.id in env)
        t = env[n.id]
    elif isinstance(n, (ast.List, ast.Set)):
        types = [expression_type(x, env, model) for x in n.elts]
        require(not types or types[0] in SCALARS and all(x == types[0] for x in types))
        t = ('vector' if isinstance(n, ast.List) else 'set', types[0] if types else None)
    elif isinstance(n, ast.Subscript):
        a = expression_type(n.value, env, model)
        require(collection(a) and a[0] == 'vector' and a[1] is not None)
        require(expression_type(n.slice, env, model) == 'int')
        require(not (isinstance(n.slice, ast.UnaryOp) and isinstance(n.slice.op, ast.USub)))
        require(not (isinstance(n.slice, ast.Constant) and n.slice.value < 0))
        t = a[1]
    elif isinstance(n, ast.BinOp):
        a, b = expression_type(n.left, env, model), expression_type(n.right, env, model)
        if collection(a):
            require(a == b and a[0] == 'set' and isinstance(n.op, (ast.BitOr, ast.BitAnd, ast.Sub)))
            t = a
        elif a == b == 'string' and isinstance(n.op, ast.Add):
            t = 'string'
        else:
            require(a in NUMBERS and b in NUMBERS and isinstance(n.op,
                    (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)))
            if isinstance(n.op, (ast.FloorDiv, ast.Mod)):
                require(a == b == 'int')
            t = 'double' if 'double' in (a, b) or isinstance(n.op, ast.Div) else 'int'
            if isinstance(n.op, ast.Pow):
                require(b == 'int')
                if isinstance(n.right, ast.UnaryOp) and isinstance(n.right.op, ast.USub):
                    t = 'double'
    elif isinstance(n, ast.UnaryOp):
        a = expression_type(n.operand, env, model)
        require(isinstance(n.op, (ast.Not, ast.UAdd, ast.USub)))
        require(a == 'bool' if isinstance(n.op, ast.Not) else a in NUMBERS)
        t = 'bool' if isinstance(n.op, ast.Not) else a
    elif isinstance(n, ast.BoolOp):
        require(all(expression_type(x, env, model) == 'bool' for x in n.values))
        t = 'bool'
    elif isinstance(n, ast.Compare):
        operands = [n.left] + n.comparators
        for left, op, right in zip(operands, n.ops, operands[1:]):
            a, b = expression_type(left, env, model), expression_type(right, env, model)
            if isinstance(op, (ast.In, ast.NotIn)):
                if collection(b) and b[1] is None and isinstance(right, ast.Name) and a in SCALARS:
                    b = (b[0], a)
                    env[right.id] = b
                    right.inferred_type = b
                require(collection(b) and b[1] == a)
            else:
                require(isinstance(op, (ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE)))
                require(a == b and a in SCALARS or a in NUMBERS and b in NUMBERS)
        # Повторный вызов в цепочке мог бы вычисляться дважды в C++.
        require(len(n.ops) == 1 or not any(isinstance(x, ast.Call) for x in ast.walk(n)))
        t = 'bool'
    elif isinstance(n, ast.Call):
        require(not n.keywords)
        if isinstance(n.func, ast.Name):
            name = n.func.id
            args = [expression_type(x, env, model) for x in n.args]
            if name == 'input':
                require(len(args) <= 1 and (not args or args == ['string']))
                t = 'string'
            elif name in ('int', 'float'):
                require(len(args) == 1 and args[0] in SCALARS)
                t = 'int' if name == 'int' else 'double'
            elif name == 'len':
                require(len(args) == 1 and (collection(args[0]) or args[0] == 'string'))
                t = 'int'
            elif name == 'set':
                require(not args)
                t = ('set', None)
            elif name in model['functions']:
                require(all(not collection(t) or isinstance(arg, ast.Name) for arg, t in zip(n.args, args)))
                t = function_call(name, args, model)
            else:
                require(False)
        elif isinstance(n.func, ast.Attribute):
            a = expression_type(n.func.value, env, model)
            args = [expression_type(x, env, model) for x in n.args]
            if n.func.attr == 'join':
                require(isinstance(n.func.value, ast.Constant) and n.func.value.value == '' and args == ['string'])
                t = 'string'
            elif n.func.attr == 'pop':
                require(collection(a) and a[0] == 'vector' and a[1] is not None and not args)
                t = 'void'
            else:
                require(False)
        else:
            require(False)
    else:
        require(False)
    n.inferred_type = t
    return t


def bind(target, t, env, model):
    require(t != 'void')
    if isinstance(target, ast.Name):
        require(target.id not in model['functions'] and target.id not in
                {'print', 'input', 'int', 'float', 'len', 'set', 'range', 'permutations'})
        env[target.id] = merge_collection(env[target.id], t) if target.id in env else t
    elif isinstance(target, ast.Subscript):
        require(expression_type(target, env, model) == t)
    else:
        require(False)


def check_block(body, env, model, function, loop):
    for n in body:
        if isinstance(n, ast.Assign):
            require(len(n.targets) == 1)
            if isinstance(n.value, ast.Name):
                require(not collection(expression_type(n.value, env, model)))
            bind(n.targets[0], expression_type(n.value, env, model), env, model)
        elif isinstance(n, ast.AugAssign):
            a = expression_type(n.target, env, model)
            fake = ast.BinOp(left=n.target, op=n.op, right=n.value)
            require(a == expression_type(fake, env, model))
            n.calculation = fake
        elif isinstance(n, ast.Expr):
            c = n.value
            require(isinstance(c, ast.Call) and not c.keywords)
            if isinstance(c.func, ast.Name) and c.func.id == 'print':
                types = [expression_type(x, env, model) for x in c.args]
                require(all(t != 'void' and (not collection(t) or t[1] is not None or isinstance(x, ast.Name)) for x, t in zip(c.args, types)))
            elif isinstance(c.func, ast.Attribute) and c.func.attr in ('append', 'add', 'remove'):
                require(isinstance(c.func.value, ast.Name) and len(c.args) == 1)
                name = c.func.value.id
                require(name in env and collection(env[name]))
                kind, item = env[name]
                require((kind == 'vector' and c.func.attr == 'append') or
                        (kind == 'set' and c.func.attr in ('add', 'remove')))
                t = expression_type(c.args[0], env, model)
                require(t in SCALARS and (item is None or t == item))
                env[name] = (kind, t)
            else:
                expression_type(c, env, model)
        elif isinstance(n, ast.If):
            require(expression_type(n.test, env, model) == 'bool')
            before = env.copy()
            left, right = before.copy(), before.copy()
            check_block(n.body, left, model, function, loop)
            check_block(n.orelse, right, model, function, loop)
            for key in left.keys() | right.keys():
                if key in left and key in right:
                    env[key] = merge_collection(left[key], right[key])
                else:
                    # Тип помним для объявления в общей области C++, доступность
                    # отдельно проверяет проход definite_assignment ниже.
                    env[key] = left.get(key, right.get(key))
        elif isinstance(n, (ast.For, ast.While)):
            require(not n.orelse)
            if isinstance(n, ast.For):
                require(isinstance(n.target, ast.Name))
                it = n.iter
                if isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'range':
                    require(not it.keywords and 1 <= len(it.args) <= 3)
                    require(all(expression_type(x, env, model) == 'int' for x in it.args))
                    range_step(it)
                    t = 'int'
                elif isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'permutations':
                    require(model['imported'] and not it.keywords and 1 <= len(it.args) <= 2)
                    require(expression_type(it.args[0], env, model) == 'string')
                    require(len(it.args) == 1 or expression_type(it.args[1], env, model) == 'int')
                    t = 'string'
                else:
                    a = expression_type(it, env, model)
                    require(collection(a) and a[1] is not None)
                    t = a[1]
                bind(n.target, t, env, model)
            else:
                require(expression_type(n.test, env, model) == 'bool')
            check_block(n.body, env, model, function, loop + 1)
        elif isinstance(n, (ast.Break, ast.Continue)):
            require(loop > 0)
        elif isinstance(n, ast.Return):
            require(function is not None)
            t = 'void' if n.value is None else expression_type(n.value, env, model)
            if function['return'] is None:
                function['return'] = t
            require(function['return'] == t)
        else:
            require(False)
