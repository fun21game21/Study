a = []
for i in range(1, 5):
    a.append(i * i)
print("Квадраты:", a)
