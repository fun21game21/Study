@echo off
setlocal
pushd "%~dp0" || exit /b 1
py -3 -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo PyInstaller not found. Install it: py -3 -m pip install pyinstaller
    popd
    exit /b 1
)
py -3 -m PyInstaller --noconfirm --clean --onefile --console --name PythonToPascalTranslator --add-data "examples;examples" main.py
set "rc=%ERRORLEVEL%"
popd
exit /b %rc%
