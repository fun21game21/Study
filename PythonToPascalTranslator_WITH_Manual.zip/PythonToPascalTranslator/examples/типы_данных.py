a = 10
x = 3.14
text = "Python to Pascal"
flag = True
print(a, x, text, flag)
