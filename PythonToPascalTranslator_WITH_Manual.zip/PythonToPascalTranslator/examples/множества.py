# Полный перебор распределений 10 камней по 3 кучам.
# Цель: минимальная сумма абсолютных отклонений от среднего веса.
weights = [78, 5, 66, 75, 28, 25, 23, 35, 20, 40]
m = 3

total_weight = 0
for w in weights:
    total_weight += w
ideal_weight = total_weight / m

variants = 1
for i in range(len(weights)):
    variants *= m

best = -1.0
best_code = 0
for code in range(variants):
    sums = []
    for j in range(m):
        sums.append(0)

    rest = code
    for i in range(len(weights)):
        pile = rest % m
        rest = rest // m
        sums[pile] += weights[i]

    deviation = 0.0
    for weight in sums:
        delta = weight - ideal_weight
        if delta < 0:
            delta = -delta
        deviation += delta

    if best < 0 or deviation < best:
        best = deviation
        best_code = code

print("Камни:", weights)
print("Количество куч:", m)
print("Идеальный вес:", ideal_weight)

pile_weights = []
for j in range(m):
    pile_weights.append(0)

rest = best_code
for i in range(len(weights)):
    pile = rest % m
    rest = rest // m
    pile_weights[pile] += weights[i]
    print("Камень", weights[i], "-> куча", pile + 1)

print("Веса куч:", pile_weights)
print("Суммарное отклонение:", best)

# Небольшая демонстрация базовых операций с множествами.
a = {1, 2, 3}
b = {3, 4}
print("Объединение:", a | b)
print("Пересечение:", a & b)
print("Разность:", a - b)
