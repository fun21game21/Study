"""Простой консольный интерфейс для учебного транслятора Python -> Pascal."""
from pathlib import Path
import sys
from translator import translate


def application_dir():
    return Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent


def resources_dir():
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))


EXAMPLES = [
    ('Типы данных', 'типы_данных.py'), ('Ввод / вывод', 'ввод_вывод.py'),
    ('Вычисления', 'вычисления.py'), ('Ветвления', 'ветвления.py'),
    ('Циклы', 'циклы.py'), ('Массивы', 'массивы_пример.py'),
    ('Функции', 'функции.py'), ('Рекурсия', 'рекурсия.py'),
    ('Задача "Массивы"', 'массивы.py'), ('Задача "Множества"', 'множества.py'),
    ('Задача "Перестановки"', 'перестановки.py'),
]
ERROR = 'Error\nПроверьте корректность и выполняемость входного файла'


def menu_choice(options):
    while True:
        v = input('Ваш выбор: ').strip()
        if v in options:
            return int(v)
        print('Некорректный выбор')


def main():
    print('========================================\n      ТРАНСЛЯТОР PYTHON -> PASCAL\n========================================\n')
    print('Выберите программу для трансляции:\n')
    for i, (title, _) in enumerate(EXAMPLES, 1):
        print(f'{i:2} - {title}')
    print('12 - Использовать файл input\n')
    try:
        n = menu_choice({str(i) for i in range(1, 13)})
        if n == 12:
            print('\nВыберите исходный файл:\n\n1 - input.py\n2 - input.txt\n')
            ext = menu_choice({'1', '2'})
            source_path = application_dir() / ('input.py' if ext == 1 else 'input.txt')
        else:
            source_path = resources_dir() / 'examples' / EXAMPLES[n - 1][1]
        pas = translate(source_path.read_text(encoding='utf-8-sig'))
        # Сначала генерируем код, затем пишем одинаковые файлы.
        for filename in ('output.pas', 'output.txt'):
            (application_dir() / filename).write_text(pas, encoding='utf-8')
        print('\nТрансляция выполнена успешно.\n\nСозданы файлы:\noutput.pas\noutput.txt')
    except Exception:
        print('\n' + ERROR)
    finally:
        if getattr(sys, 'frozen', False):
            try:
                input('\nНажмите Enter для выхода...')
            except EOFError:
                pass


if __name__ == '__main__':
    if sys.platform == 'win32':
        for stream in (sys.stdin, sys.stdout, sys.stderr):
            if hasattr(stream, 'reconfigure'):
                stream.reconfigure(encoding='utf-8')
    main()
