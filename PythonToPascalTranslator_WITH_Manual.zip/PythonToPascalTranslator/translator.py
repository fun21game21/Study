"""Учебный переводчик ограниченного Python AST в Free Pascal (objfpc).

Нет собственного лексера и классов компилятора. Перед генерацией простой
анализатор проверяет поддерживаемые конструкции и определяет типы переменных.
"""
import ast

from analyzer import analyze, collection, require, range_step
from parser import parse_source

PASCAL_RESERVED = set(('and array as asm begin case class const constructor destructor div do '
                       'downto else end except exports file finalization finally for function '
                       'goto if implementation in inherited initialization inline interface '
                       'is label library mod nil not object of on operator or out packed '
                       'procedure program property raise record repeat resourcestring set '
                       'shl shr string then threadvar to try type unit until uses var while '
                       'with xor result true false integer double boolean exit length write '
                       'writeln readln setlength high low inc dec').split())

TYPES = {'int': 'Integer', 'double': 'Double', 'string': 'string', 'bool': 'Boolean'}
SUFFIX = {'int': 'Int', 'double': 'Double', 'string': 'String', 'bool': 'Bool'}


def name(identifier):
    # Pascal не различает регистр идентификаторов.
    return identifier + '_value' if identifier.lower() in PASCAL_RESERVED or identifier.startswith('translator_') else identifier


def type_name(t):
    if collection(t):
        require(t[1] in TYPES)
        return 'T' + SUFFIX[t[1]] + 'Array'
    require(t in TYPES)
    return TYPES[t]


def literal(s):
    # Однострочные строковые литералы: двойная кавычка Pascal не нужна.
    require('\n' not in s and '\r' not in s and '\0' not in s)
    return "'" + s.replace("'", "''") + "'"


def collect_types(model):
    result = set()
    for env in [model['env']] + [f['env'] for f in model['functions'].values()]:
        for t in env.values():
            if collection(t):
                result.add(t[1])
    return result


def temp(state, prefix, t, env):
    state['counter'] += 1
    label = 'translator_' + prefix + str(state['counter'])
    # Имена временных переменных объявляются до begin в var.
    state['temporary'].append((label, t))
    return label


def exp(n, state, env):
    if isinstance(n, ast.Constant):
        if type(n.value) is str:
            return literal(n.value)
        if type(n.value) is bool:
            return 'True' if n.value else 'False'
        return repr(n.value)
    if isinstance(n, ast.Name):
        return name(n.id)
    if isinstance(n, ast.Subscript):
        return exp(n.value, state, env) + '[' + exp(n.slice, state, env) + ']'
    if isinstance(n, ast.BinOp):
        a, b = exp(n.left, state, env), exp(n.right, state, env)
        if collection(n.left.inferred_type):
            require(n.left.inferred_type[0] == 'set')
            operation = {ast.BitOr: 'Union', ast.BitAnd: 'Intersect', ast.Sub: 'Difference'}[type(n.op)]
            scalar = n.left.inferred_type[1]
            state['set_helpers'].add(scalar)
            return 'Set' + operation + SUFFIX[scalar] + '(' + a + ', ' + b + ')'
        if isinstance(n.op, ast.Pow):
            state['units'].add('Math')
            result = 'Power(' + a + ', ' + b + ')'
            return 'Trunc(' + result + ')' if n.inferred_type == 'int' else result
        if isinstance(n.op, ast.Div):
            return '(' + a + ' / ' + b + ')'
        if isinstance(n.op, ast.FloorDiv):
            return '(' + a + ' div ' + b + ')'
        if isinstance(n.op, ast.Mod):
            return '(' + a + ' mod ' + b + ')'
        if isinstance(n.op, ast.Add) and n.inferred_type == 'string':
            return '(' + a + ' + ' + b + ')'
        op = {ast.Add: '+', ast.Sub: '-', ast.Mult: '*'}[type(n.op)]
        return '(' + a + ' ' + op + ' ' + b + ')'
    if isinstance(n, ast.UnaryOp):
        op = {ast.Not: 'not ', ast.USub: '-', ast.UAdd: '+'}[type(n.op)]
        return '(' + op + exp(n.operand, state, env) + ')'
    if isinstance(n, ast.BoolOp):
        op = ' and ' if isinstance(n.op, ast.And) else ' or '
        return '(' + op.join(exp(x, state, env) for x in n.values) + ')'
    if isinstance(n, ast.Compare):
        parts = []
        operands = [n.left] + n.comparators
        for left, op, right in zip(operands, n.ops, operands[1:]):
            if isinstance(op, (ast.In, ast.NotIn)):
                t = right.inferred_type
                require(collection(t))
                scalar = t[1]
                state['contains_helpers'].add(scalar)
                part = 'Contains' + SUFFIX[scalar] + '(' + exp(right, state, env) + ', ' + exp(left, state, env) + ')'
                if isinstance(op, ast.NotIn):
                    part = 'not ' + part
                parts.append('(' + part + ')')
            else:
                operator = {ast.Eq: '=', ast.NotEq: '<>', ast.Lt: '<', ast.LtE: '<=',
                            ast.Gt: '>', ast.GtE: '>='}[type(op)]
                parts.append('(' + exp(left, state, env) + ' ' + operator + ' ' + exp(right, state, env) + ')')
        return '(' + ' and '.join(parts) + ')'
    if isinstance(n, ast.Call):
        args = [exp(a, state, env) for a in n.args]
        if isinstance(n.func, ast.Name):
            fn = n.func.id
            if fn == 'len':
                return 'Length(' + args[0] + ')'
            if fn == 'int':
                return 'Trunc(' + args[0] + ')'
            if fn == 'float':
                return 'Double(' + args[0] + ')'
            if fn == 'input':
                raise ValueError('input() supported only as assignment')
            if fn == 'set':
                raise ValueError('set() supported only as assignment')
            return name(fn) + '(' + ', '.join(args) + ')'
        if isinstance(n.func, ast.Attribute):
            if n.func.attr == 'join':
                # В разрешённом Python-фрагменте p уже представлена строкой.
                return args[0]
            raise ValueError('Unsupported expression method')
    raise ValueError('Unsupported expression')


def write_array_helper(scalar):
    suf = SUFFIX[scalar]
    arr = 'T' + suf + 'Array'
    return f'''procedure PrintArray{suf}(const a: {arr});
var
  k: Integer;
begin
  for k := 0 to Length(a) - 1 do
  begin
    if k > 0 then Write(' ');
    Write(a[k]);
  end;
end;
'''


def set_helper(scalar):
    suf = SUFFIX[scalar]
    typ = TYPES[scalar]
    arr = 'T' + suf + 'Array'
    return f'''function Contains{suf}(const a: {arr}; value: {typ}): Boolean;
var
  k: Integer;
begin
  Result := False;
  for k := 0 to Length(a) - 1 do
    if a[k] = value then
      Exit(True);
end;

procedure SetAdd{suf}(var a: {arr}; value: {typ});
begin
  if not Contains{suf}(a, value) then
  begin
    SetLength(a, Length(a) + 1);
    a[High(a)] := value;
  end;
end;

procedure SetRemove{suf}(var a: {arr}; value: {typ});
var
  i, j: Integer;
begin
  for i := 0 to Length(a) - 1 do
    if a[i] = value then
    begin
      for j := i to Length(a) - 2 do a[j] := a[j + 1];
      SetLength(a, Length(a) - 1);
      Exit;
    end;
end;

function SetUnion{suf}(const a, b: {arr}): {arr};
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do SetAdd{suf}(Result, a[i]);
  for i := 0 to Length(b) - 1 do SetAdd{suf}(Result, b[i]);
end;

function SetIntersect{suf}(const a, b: {arr}): {arr};
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if Contains{suf}(b, a[i]) then SetAdd{suf}(Result, a[i]);
end;

function SetDifference{suf}(const a, b: {arr}): {arr};
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if not Contains{suf}(b, a[i]) then SetAdd{suf}(Result, a[i]);
end;
'''


def permutations_helper():
    # Упрощённая учебная реализация: однобайтовая латиница, разные позиции.
    return '''function PermutationsAscii(const word: string; k: Integer): TStringArray;
var
  used: TBoolArray;
  current: string;
  output_values: TStringArray;
  count: Integer;
  procedure Visit(depth: Integer);
  var
    i: Integer;
  begin
    if depth = k then
    begin
      SetLength(output_values, count + 1);
      output_values[count] := current;
      Inc(count);
      Exit;
    end;
    for i := 1 to Length(word) do
      if not used[i - 1] then
      begin
        used[i - 1] := True;
        current := current + word[i];
        Visit(depth + 1);
        Delete(current, Length(current), 1);
        used[i - 1] := False;
      end;
  end;
begin
  count := 0;
  SetLength(Result, 0);
  if (k < 0) or (k > Length(word)) then Exit;
  SetLength(output_values, 0);
  SetLength(used, Length(word));
  current := '';
  Visit(0);
  Result := output_values;
end;
'''


def block(body, env, state, level=1, function=None):
    lines = []
    ind = '  ' * level
    for n in body:
        if isinstance(n, ast.Assign):
            require(len(n.targets) == 1)
            dest = n.targets[0]
            if isinstance(dest, ast.Name) and isinstance(n.value, (ast.List, ast.Set)):
                label = name(dest.id)
                if isinstance(n.value, ast.List) and n.value.elts:
                    values = ', '.join(exp(item, state, env) for item in n.value.elts)
                    lines.append(ind + label + ' := ' + type_name(env[dest.id]) + '.Create(' + values + ');')
                else:
                    lines.append(ind + 'SetLength(' + label + ', 0);')
                if isinstance(n.value, ast.Set):
                    scalar = env[dest.id][1]
                    state['set_helpers'].add(scalar)
                    for item in n.value.elts:
                        lines.append(ind + 'SetAdd' + SUFFIX[scalar] + '(' + label + ', ' + exp(item, state, env) + ');')
                continue
            if isinstance(dest, ast.Name) and isinstance(n.value, ast.Call):
                call = n.value
                value = call
                if isinstance(call.func, ast.Name) and call.func.id in ('int', 'float') and call.args:
                    value = call.args[0]
                if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'input':
                    if value.args:
                        lines.append(ind + 'Write(' + exp(value.args[0], state, env) + ');')
                    lines.append(ind + 'ReadLn(' + name(dest.id) + ');')
                    continue
                if isinstance(call.func, ast.Name) and call.func.id == 'set':
                    lines.append(ind + 'SetLength(' + name(dest.id) + ', 0);')
                    continue
            lines.append(ind + exp(dest, state, env) + ' := ' + exp(n.value, state, env) + ';')
        elif isinstance(n, ast.AugAssign):
            target = exp(n.target, state, env)
            lines.append(ind + target + ' := ' + exp(n.calculation, state, env) + ';')
        elif isinstance(n, ast.Expr):
            c = n.value
            if isinstance(c.func, ast.Name) and c.func.id == 'print':
                for i, arg in enumerate(c.args):
                    if i:
                        lines.append(ind + "Write(' ');")
                    t = arg.inferred_type
                    if collection(t):
                        state['print_helpers'].add(t[1])
                        lines.append(ind + 'PrintArray' + SUFFIX[t[1]] + '(' + exp(arg, state, env) + ');')
                    else:
                        lines.append(ind + 'Write(' + exp(arg, state, env) + ');')
                lines.append(ind + 'WriteLn;')
            elif isinstance(c.func, ast.Attribute):
                container = c.func.value
                require(isinstance(container, ast.Name))
                label = name(container.id)
                method = c.func.attr
                t = env[container.id]
                if method == 'append':
                    lines.extend([ind + 'SetLength(' + label + ', Length(' + label + ') + 1);',
                                  ind + label + '[High(' + label + ')] := ' + exp(c.args[0], state, env) + ';'])
                elif method == 'pop':
                    lines.append(ind + 'SetLength(' + label + ', Length(' + label + ') - 1);')
                elif method in ('add', 'remove'):
                    scalar = t[1]
                    state['set_helpers'].add(scalar)
                    lines.append(ind + ('SetAdd' if method == 'add' else 'SetRemove') + SUFFIX[scalar] +
                                 '(' + label + ', ' + exp(c.args[0], state, env) + ');')
                else:
                    raise ValueError('Unsupported statement method')
            else:
                # Предполагаются поддерживаемые вызовы пользовательских процедур.
                lines.append(ind + exp(c, state, env) + ';')
        elif isinstance(n, ast.If):
            lines.append(ind + 'if ' + exp(n.test, state, env) + ' then')
            lines.append(ind + 'begin')
            lines.extend(block(n.body, env, state, level + 1, function))
            if n.orelse:
                lines.append(ind + 'end')
                lines.append(ind + 'else')
                lines.append(ind + 'begin')
                lines.extend(block(n.orelse, env, state, level + 1, function))
                lines.append(ind + 'end;')
            else:
                lines.append(ind + 'end;')
        elif isinstance(n, ast.While):
            lines.append(ind + 'while ' + exp(n.test, state, env) + ' do')
            lines.append(ind + 'begin')
            lines.extend(block(n.body, env, state, level + 1, function))
            lines.append(ind + 'end;')
        elif isinstance(n, ast.For):
            it = n.iter
            target = name(n.target.id)
            if isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'range':
                args = [exp(a, state, env) for a in it.args]
                start, stop = ('0', args[0]) if len(args) == 1 else (args[0], args[1])
                step = range_step(it)
                if step == 1 or step == -1:
                    bound = '(' + stop + ' - 1)' if step == 1 else '(' + stop + ' + 1)'
                    direction = 'to' if step == 1 else 'downto'
                    lines.extend([ind + f'for {target} := {start} {direction} {bound} do', ind + 'begin'])
                    lines.extend(block(n.body, env, state, level + 1, function))
                    lines.append(ind + 'end;')
                else:
                    # Для step != ±1 `continue` усложняет обновление счётчика.
                    require(not any(isinstance(x, ast.Continue) for x in ast.walk(n)))
                    lines.append(ind + f'{target} := {start};')
                    condition = '<' if step > 0 else '>'
                    lines.extend([ind + f'while {target} {condition} {stop} do', ind + 'begin'])
                    lines.extend(block(n.body, env, state, level + 1, function))
                    lines.append(ind + f'  {target} := {target} + ({step});')
                    lines.append(ind + 'end;')
            elif isinstance(it, ast.Call) and isinstance(it.func, ast.Name) and it.func.id == 'permutations':
                state['permutations'] = True
                length_arg = (exp(it.args[1], state, env) if len(it.args) == 2
                              else 'Length(' + exp(it.args[0], state, env) + ')')
                local = temp(state, 'perms', ('vector', 'string'), env)
                lines.append(ind + local + ' := PermutationsAscii(' + exp(it.args[0], state, env) + ', ' + length_arg + ');')
                lines.extend([ind + f'for {target} in {local} do', ind + 'begin'])
                lines.extend(block(n.body, env, state, level + 1, function))
                lines.append(ind + 'end;')
            else:
                lines.extend([ind + f'for {target} in {exp(it, state, env)} do', ind + 'begin'])
                lines.extend(block(n.body, env, state, level + 1, function))
                lines.append(ind + 'end;')
        elif isinstance(n, ast.Return):
            lines.append(ind + ('Exit(' + exp(n.value, state, env) + ');' if n.value else 'Exit;'))
        elif isinstance(n, ast.Break):
            lines.append(ind + 'Break;')
        elif isinstance(n, ast.Continue):
            lines.append(ind + 'Continue;')
        else:
            raise ValueError('Unsupported statement')
    return lines


def variable_declarations(env, skip=(), extra=()):
    names = [(name(k), type_name(v)) for k, v in env.items() if k not in skip]
    names += [(k, type_name(t)) for k, t in extra]
    if not names:
        return []
    return ['var'] + ['  ' + k + ': ' + t + ';' for k, t in names]


def translate(source):
    model = analyze(parse_source(source))
    names = list(model['env']) + list(model['functions'])
    for f in model['functions'].values():
        names.extend(f['env'])
    # Обрабатываем конфликты имён с учётом регистронезависимости Pascal.
    mapped = [name(n).lower() for n in names]
    # Локальные имена разных функций могут совпадать. Коллизии только в
    # пределах одной области (main или отдельная функция).
    for env in [model['env']] + [f['env'] for f in model['functions'].values()]:
        ids = [name(x).lower() for x in env]
        require(len(ids) == len(set(ids)))
    scalar_types = collect_types(model)
    state = {'units': set(), 'counter': 0, 'temporary': [], 'print_helpers': set(),
             'contains_helpers': set(), 'set_helpers': set(), 'permutations': False}
    compiled_functions = []
    for fname, f in model['functions'].items():
        temp_start = len(state['temporary'])
        body = block(f['node'].body, f['env'], state, 1, f)
        extras = state['temporary'][temp_start:]
        state['temporary'] = state['temporary'][:temp_start]
        params = '; '.join(name(x.arg) + ': ' + type_name(t)
                           for x, t in zip(f['node'].args.args, f['params']))
        if f['return'] == 'void':
            header = 'procedure ' + name(fname) + '(' + params + ');'
        else:
            header = 'function ' + name(fname) + '(' + params + '): ' + type_name(f['return']) + ';'
        local_vars = variable_declarations(f['env'], [x.arg for x in f['node'].args.args], extras)
        compiled_functions += [header] + local_vars + ['begin'] + body + ['end;', '']
    main_body = block(model['main'], model['env'], state, 1)
    scalar_types.update(t[1] for _, t in state['temporary'] if collection(t))
    if state['permutations']:
        scalar_types.update({'string', 'bool'})
    defs = []
    if scalar_types:
        defs.append('type')
        for scalar in sorted(scalar_types):
            defs.append('  T' + SUFFIX[scalar] + 'Array = array of ' + TYPES[scalar] + ';')
        defs.append('')
    helpers = []
    for scalar in sorted(state['set_helpers'] | state['contains_helpers']):
        # Один небольшой комплект помогает не создавать разные generic runtime.
        helpers.append(set_helper(scalar))
    for scalar in sorted(state['print_helpers']):
        helpers.append(write_array_helper(scalar))
    if state['permutations']:
        helpers.append(permutations_helper())
    header = ['program TranslatedProgram;', '{$mode objfpc}', '{$H+}', '{$codepage utf8}', '']
    if state['units']:
        header.extend(['uses ' + ', '.join(sorted(state['units'])) + ';', ''])
    text = header + defs + variable_declarations(model['env'], extra=state['temporary']) + [''] + helpers + compiled_functions + ['begin'] + main_body + ['end.']
    return '\n'.join(text).rstrip() + '\n'
