program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

type
  TIntArray = array of Integer;

var
  a: TIntArray;
  i: Integer;

procedure PrintArrayInt(const a: TIntArray);
var
  k: Integer;
begin
  for k := 0 to Length(a) - 1 do
  begin
    if k > 0 then Write(' ');
    Write(a[k]);
  end;
end;

begin
  SetLength(a, 0);
  for i := 1 to (5 - 1) do
  begin
    SetLength(a, Length(a) + 1);
    a[High(a)] := (i * i);
  end;
  Write('Квадраты:');
  Write(' ');
  PrintArrayInt(a);
  WriteLn;
end.
