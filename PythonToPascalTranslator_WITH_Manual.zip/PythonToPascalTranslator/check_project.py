"""Компактная проверка учебного проекта; FPC использует только если доступен."""
from pathlib import Path
import contextlib
import io
import shutil
import subprocess
import sys
import tempfile

from translator import translate
from main import EXAMPLES, ERROR

ROOT = Path(__file__).resolve().parent
CASES = {'ввод_вывод.py': 'Max\n20\n1.8\n'}


def check():
    count = 0
    for caption, filename in EXAMPLES:
        source = (ROOT / 'examples' / filename).read_text(encoding='utf-8')
        code = translate(source)
        assert code.startswith('program TranslatedProgram;')
        assert code.rstrip().endswith('end.')
        assert 'bits/stdc++.h' not in code
        assert 'using namespace' not in code
        count += 1
        print('PASS перевод:', filename)

    for inputname in ('input.py', 'input.txt'):
        code = translate((ROOT / inputname).read_text(encoding='utf-8'))
        assert 'program TranslatedProgram;' in code
        count += 1
        print('PASS пользовательский файл:', inputname)

    for bad in ['class A:\n    pass\n', 'a = [1\n', 'a = 10\na = "text"\n']:
        try:
            translate(bad)
        except Exception:
            count += 1
        else:
            raise AssertionError('Некорректный вход принят')
    print('PASS 3 случая ошибок')

    rain = ROOT / 'examples' / 'массивы.py'
    ns = {}
    with contextlib.redirect_stdout(io.StringIO()) as output:
        exec(compile(rain.read_text(encoding='utf-8'), str(rain), 'exec'), ns)
    assert output.getvalue().strip() == '21'
    count += 1
    print('PASS массивы.py = 21')

    stones = ROOT / 'examples' / 'множества.py'
    with contextlib.redirect_stdout(io.StringIO()) as output:
        exec(compile(stones.read_text(encoding='utf-8'), str(stones), 'exec'), {})
    assert 'Суммарное отклонение:' in output.getvalue()
    assert '2.6666' in output.getvalue()
    count += 1
    print('PASS множества.py — точный перебор')

    fpc = shutil.which('fpc')
    if not fpc:
        print('SKIP: Free Pascal Compiler не установлен; Pascal не компилировался')
        return count
    with tempfile.TemporaryDirectory() as tmp:
        directory = Path(tmp)
        for _, filename in EXAMPLES:
            code = translate((ROOT / 'examples' / filename).read_text(encoding='utf-8'))
            pas = directory / (Path(filename).stem + '.pas')
            pas.write_text(code, encoding='utf-8')
            result = subprocess.run([fpc, '-B', '-FE'+tmp, '-FU'+tmp, str(pas)],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            if result.returncode:
                raise AssertionError(f'FPC: {filename}\n{result.stdout}')
            print('PASS FPC:', filename)
            count += 1
    return count


if __name__ == '__main__':
    try:
        print(f'Всего успешных проверок: {check()}')
    except Exception as error:
        print('FAIL:', error, file=sys.stderr)
        raise SystemExit(1)
