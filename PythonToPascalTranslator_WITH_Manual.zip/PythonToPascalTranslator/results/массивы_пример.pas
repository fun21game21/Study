program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

type
  TIntArray = array of Integer;

var
  a: TIntArray;
  x: Integer;

procedure PrintArrayInt(const a: TIntArray);
var
  k: Integer;
begin
  for k := 0 to Length(a) - 1 do
  begin
    if k > 0 then Write(' ');
    Write(a[k]);
  end;
end;

begin
  a := TIntArray.Create(1, 2, 3);
  a[1] := 5;
  SetLength(a, Length(a) + 1);
  a[High(a)] := 7;
  Write(a[0]);
  Write(' ');
  Write(Length(a));
  WriteLn;
  for x in a do
  begin
    Write(x);
    WriteLn;
  end;
  SetLength(a, Length(a) - 1);
  PrintArrayInt(a);
  WriteLn;
end.
