program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

type
  TBoolArray = array of Boolean;
  TStringArray = array of string;

var
  word: string;
  words: TStringArray;
  found: TStringArray;
  k: Integer;
  p: string;
  candidate: string;
  translator_perms1: TStringArray;

function ContainsString(const a: TStringArray; value: string): Boolean;
var
  k: Integer;
begin
  Result := False;
  for k := 0 to Length(a) - 1 do
    if a[k] = value then
      Exit(True);
end;

procedure SetAddString(var a: TStringArray; value: string);
begin
  if not ContainsString(a, value) then
  begin
    SetLength(a, Length(a) + 1);
    a[High(a)] := value;
  end;
end;

procedure SetRemoveString(var a: TStringArray; value: string);
var
  i, j: Integer;
begin
  for i := 0 to Length(a) - 1 do
    if a[i] = value then
    begin
      for j := i to Length(a) - 2 do a[j] := a[j + 1];
      SetLength(a, Length(a) - 1);
      Exit;
    end;
end;

function SetUnionString(const a, b: TStringArray): TStringArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do SetAddString(Result, a[i]);
  for i := 0 to Length(b) - 1 do SetAddString(Result, b[i]);
end;

function SetIntersectString(const a, b: TStringArray): TStringArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if ContainsString(b, a[i]) then SetAddString(Result, a[i]);
end;

function SetDifferenceString(const a, b: TStringArray): TStringArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if not ContainsString(b, a[i]) then SetAddString(Result, a[i]);
end;

function PermutationsAscii(const word: string; k: Integer): TStringArray;
var
  used: TBoolArray;
  current: string;
  output_values: TStringArray;
  count: Integer;
  procedure Visit(depth: Integer);
  var
    i: Integer;
  begin
    if depth = k then
    begin
      SetLength(output_values, count + 1);
      output_values[count] := current;
      Inc(count);
      Exit;
    end;
    for i := 1 to Length(word) do
      if not used[i - 1] then
      begin
        used[i - 1] := True;
        current := current + word[i];
        Visit(depth + 1);
        Delete(current, Length(current), 1);
        used[i - 1] := False;
      end;
  end;
begin
  count := 0;
  SetLength(Result, 0);
  if (k < 0) or (k > Length(word)) then Exit;
  SetLength(output_values, 0);
  SetLength(used, Length(word));
  current := '';
  Visit(0);
  Result := output_values;
end;

begin
  word := 'stop';
  words := TStringArray.Create('stop', 'post', 'spot', 'top', 'pot', 'so', 'to');
  SetLength(found, 0);
  for k := 1 to ((Length(word) + 1) - 1) do
  begin
    translator_perms1 := PermutationsAscii(word, k);
    for p in translator_perms1 do
    begin
      candidate := p;
      if (((ContainsString(words, candidate))) and ((not ContainsString(found, candidate)))) then
      begin
        SetAddString(found, candidate);
        Write(candidate);
        WriteLn;
      end;
    end;
  end;
  Write('Найдено:');
  Write(' ');
  Write(Length(found));
  WriteLn;
end.
