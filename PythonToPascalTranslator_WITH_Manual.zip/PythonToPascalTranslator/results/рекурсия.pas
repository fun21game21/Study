program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}


function factorial(n: Integer): Integer;
begin
  if ((n = 0)) then
  begin
    Exit(1);
  end;
  Exit((n * factorial((n - 1))));
end;

begin
  Write(factorial(5));
  WriteLn;
end.
