program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

var
  a: Integer;
  x: Double;
  text: string;
  flag: Boolean;

begin
  a := 10;
  x := 3.14;
  text := 'Python to Pascal';
  flag := True;
  Write(a);
  Write(' ');
  Write(x);
  Write(' ');
  Write(text);
  Write(' ');
  Write(flag);
  WriteLn;
end.
