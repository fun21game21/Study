program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

var
  n: Integer;

begin
  n := 7;
  if ((n < 0)) then
  begin
    Write('Отрицательное');
    WriteLn;
  end
  else
  begin
    if ((n = 0)) then
    begin
      Write('Ноль');
      WriteLn;
    end
    else
    begin
      if (((n > 0)) and (not ((n = 10)))) then
      begin
        Write('Положительное, не десять');
        WriteLn;
      end;
    end;
  end;
end.
