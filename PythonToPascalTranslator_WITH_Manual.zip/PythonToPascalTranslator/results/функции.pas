program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

var
  result_value: Integer;

function summa(a: Integer; b: Integer): Integer;
begin
  Exit((a + b));
end;

procedure show(x: Integer);
begin
  Write('Результат:');
  Write(' ');
  Write(x);
  WriteLn;
end;

begin
  result_value := summa(5, 3);
  show(result_value);
end.
