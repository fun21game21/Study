program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

var
  total: Integer;
  i: Integer;
  j: Integer;
  n: Integer;

begin
  total := 0;
  for i := 1 to (6 - 1) do
  begin
    if ((i = 3)) then
    begin
      Continue;
    end;
    total := (total + i);
  end;
  Write(total);
  WriteLn;
  j := 5;
  while j > 0 do
  begin
    Write(j);
    WriteLn;
    j := j + (-2);
  end;
  n := 0;
  while ((n < 10)) do
  begin
    n := (n + 1);
    if ((n = 3)) then
    begin
      Break;
    end;
  end;
  Write(n);
  WriteLn;
end.
