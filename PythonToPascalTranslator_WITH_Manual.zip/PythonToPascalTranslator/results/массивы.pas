program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

type
  TIntArray = array of Integer;

var
  a: TIntArray;
  water: Integer;
  i: Integer;
  left: Integer;
  right: Integer;
  j: Integer;
  level: Integer;

begin
  a := TIntArray.Create(2, 5, 1, 2, 3, 4, 7, 7, 6, 1, 3, 9, 4, 3);
  water := 0;
  for i := 1 to ((Length(a) - 1) - 1) do
  begin
    left := a[i];
    right := a[i];
    for j := 0 to (i - 1) do
    begin
      if ((a[j] > left)) then
      begin
        left := a[j];
      end;
    end;
    for j := (i + 1) to (Length(a) - 1) do
    begin
      if ((a[j] > right)) then
      begin
        right := a[j];
      end;
    end;
    level := left;
    if ((right < level)) then
    begin
      level := right;
    end;
    water := (water + (level - a[i]));
  end;
  Write(water);
  WriteLn;
end.
