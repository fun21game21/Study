program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

var
  name: string;
  age: Integer;
  height: Double;

begin
  Write('Введите имя: ');
  ReadLn(name);
  Write('Введите возраст: ');
  ReadLn(age);
  Write('Введите рост: ');
  ReadLn(height);
  Write('Имя:');
  Write(' ');
  Write(name);
  WriteLn;
  Write('Возраст:');
  Write(' ');
  Write(age);
  WriteLn;
  Write('Рост:');
  Write(' ');
  Write(height);
  WriteLn;
end.
