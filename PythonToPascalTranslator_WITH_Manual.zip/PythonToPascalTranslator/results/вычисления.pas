program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

uses Math;

var
  a: Integer;
  b: Integer;
  x: Double;

begin
  a := 10;
  b := 3;
  Write((a + b));
  Write(' ');
  Write((a - b));
  Write(' ');
  Write((a * b));
  WriteLn;
  Write((a / b));
  Write(' ');
  Write((a div b));
  Write(' ');
  Write((a mod b));
  Write(' ');
  Write(Trunc(Power(a, 2)));
  WriteLn;
  a := (a + 2);
  a := (a - 1);
  a := (a * 2);
  x := 8.0;
  x := (x / 2);
  Write(a);
  Write(' ');
  Write(x);
  WriteLn;
end.
