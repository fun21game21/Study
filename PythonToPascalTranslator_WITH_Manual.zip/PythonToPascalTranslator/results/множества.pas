program TranslatedProgram;
{$mode objfpc}
{$H+}
{$codepage utf8}

type
  TIntArray = array of Integer;

var
  weights: TIntArray;
  m: Integer;
  total_weight: Integer;
  w: Integer;
  ideal_weight: Double;
  variants: Integer;
  i: Integer;
  best: Double;
  best_code: Integer;
  code: Integer;
  sums: TIntArray;
  j: Integer;
  rest: Integer;
  pile: Integer;
  deviation: Double;
  weight: Integer;
  delta: Double;
  pile_weights: TIntArray;
  a: TIntArray;
  b: TIntArray;

function ContainsInt(const a: TIntArray; value: Integer): Boolean;
var
  k: Integer;
begin
  Result := False;
  for k := 0 to Length(a) - 1 do
    if a[k] = value then
      Exit(True);
end;

procedure SetAddInt(var a: TIntArray; value: Integer);
begin
  if not ContainsInt(a, value) then
  begin
    SetLength(a, Length(a) + 1);
    a[High(a)] := value;
  end;
end;

procedure SetRemoveInt(var a: TIntArray; value: Integer);
var
  i, j: Integer;
begin
  for i := 0 to Length(a) - 1 do
    if a[i] = value then
    begin
      for j := i to Length(a) - 2 do a[j] := a[j + 1];
      SetLength(a, Length(a) - 1);
      Exit;
    end;
end;

function SetUnionInt(const a, b: TIntArray): TIntArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do SetAddInt(Result, a[i]);
  for i := 0 to Length(b) - 1 do SetAddInt(Result, b[i]);
end;

function SetIntersectInt(const a, b: TIntArray): TIntArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if ContainsInt(b, a[i]) then SetAddInt(Result, a[i]);
end;

function SetDifferenceInt(const a, b: TIntArray): TIntArray;
var
  i: Integer;
begin
  SetLength(Result, 0);
  for i := 0 to Length(a) - 1 do
    if not ContainsInt(b, a[i]) then SetAddInt(Result, a[i]);
end;

procedure PrintArrayInt(const a: TIntArray);
var
  k: Integer;
begin
  for k := 0 to Length(a) - 1 do
  begin
    if k > 0 then Write(' ');
    Write(a[k]);
  end;
end;

begin
  weights := TIntArray.Create(78, 5, 66, 75, 28, 25, 23, 35, 20, 40);
  m := 3;
  total_weight := 0;
  for w in weights do
  begin
    total_weight := (total_weight + w);
  end;
  ideal_weight := (total_weight / m);
  variants := 1;
  for i := 0 to (Length(weights) - 1) do
  begin
    variants := (variants * m);
  end;
  best := (-1.0);
  best_code := 0;
  for code := 0 to (variants - 1) do
  begin
    SetLength(sums, 0);
    for j := 0 to (m - 1) do
    begin
      SetLength(sums, Length(sums) + 1);
      sums[High(sums)] := 0;
    end;
    rest := code;
    for i := 0 to (Length(weights) - 1) do
    begin
      pile := (rest mod m);
      rest := (rest div m);
      sums[pile] := (sums[pile] + weights[i]);
    end;
    deviation := 0.0;
    for weight in sums do
    begin
      delta := (weight - ideal_weight);
      if ((delta < 0)) then
      begin
        delta := (-delta);
      end;
      deviation := (deviation + delta);
    end;
    if (((best < 0)) or ((deviation < best))) then
    begin
      best := deviation;
      best_code := code;
    end;
  end;
  Write('Камни:');
  Write(' ');
  PrintArrayInt(weights);
  WriteLn;
  Write('Количество куч:');
  Write(' ');
  Write(m);
  WriteLn;
  Write('Идеальный вес:');
  Write(' ');
  Write(ideal_weight);
  WriteLn;
  SetLength(pile_weights, 0);
  for j := 0 to (m - 1) do
  begin
    SetLength(pile_weights, Length(pile_weights) + 1);
    pile_weights[High(pile_weights)] := 0;
  end;
  rest := best_code;
  for i := 0 to (Length(weights) - 1) do
  begin
    pile := (rest mod m);
    rest := (rest div m);
    pile_weights[pile] := (pile_weights[pile] + weights[i]);
    Write('Камень');
    Write(' ');
    Write(weights[i]);
    Write(' ');
    Write('-> куча');
    Write(' ');
    Write((pile + 1));
    WriteLn;
  end;
  Write('Веса куч:');
  Write(' ');
  PrintArrayInt(pile_weights);
  WriteLn;
  Write('Суммарное отклонение:');
  Write(' ');
  Write(best);
  WriteLn;
  SetLength(a, 0);
  SetAddInt(a, 1);
  SetAddInt(a, 2);
  SetAddInt(a, 3);
  SetLength(b, 0);
  SetAddInt(b, 3);
  SetAddInt(b, 4);
  Write('Объединение:');
  Write(' ');
  PrintArrayInt(SetUnionInt(a, b));
  WriteLn;
  Write('Пересечение:');
  Write(' ');
  PrintArrayInt(SetIntersectInt(a, b));
  WriteLn;
  Write('Разность:');
  Write(' ');
  PrintArrayInt(SetDifferenceInt(a, b));
  WriteLn;
end.
