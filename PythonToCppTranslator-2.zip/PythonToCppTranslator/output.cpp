#include <iostream>
#include <random>
#include <vector>

using namespace std;

int translator_randint(int low, int high)
{
    static mt19937 generator(random_device{}());
    return uniform_int_distribution<int>(low, high)(generator);
}

void find_best_distribution(vector<int>& weights, int m, int index, vector<int>& distribution, vector<int>& best_distribution, vector<double>& best_deviation, double ideal_weight);

void find_best_distribution(vector<int>& weights, int m, int index, vector<int>& distribution, vector<int>& best_distribution, vector<double>& best_deviation, double ideal_weight)
{
    if (index == static_cast<int>(weights.size()))
    {
        vector<int> pile_weights;
        for (int j = 0; j < m; j++)
        {
            pile_weights.push_back(0);
        }
        for (int i = 0; i < weights.size(); i++)
        {
            int pile = distribution[i];
            pile_weights[pile] += weights[i];
        }
        double total_deviation = 0.0;
        for (int j = 0; j < m; j++)
        {
            double deviation = pile_weights[j] - ideal_weight;
            if (deviation < 0.0)
            {
                deviation = -deviation;
            }
            total_deviation += deviation;
        }
        if (best_deviation[0] < 0.0 || total_deviation < best_deviation[0])
        {
            best_deviation[0] = total_deviation;
            for (int i = 0; i < weights.size(); i++)
            {
                best_distribution[i] = distribution[i];
            }
        }
        return;
    }
    for (int pile = 0; pile < m; pile++)
    {
        distribution[index] = pile;
        find_best_distribution(weights, m, index + 1, distribution, best_distribution, best_deviation, ideal_weight);
    }
}

int main()
{
    vector<int> weights;
    for (int i = 0; i < 6; i++)
    {
        weights.push_back(translator_randint(1, 10));
    }
    int m = 3;
    int total_weight = 0;
    for (int i = 0; i < weights.size(); i++)
    {
        total_weight += weights[i];
    }
    double ideal_weight = static_cast<double>(total_weight) / m;
    vector<int> distribution;
    vector<int> best_distribution;
    for (int i = 0; i < weights.size(); i++)
    {
        distribution.push_back(0);
        best_distribution.push_back(0);
    }
    vector<double> best_deviation = {-1.0};
    find_best_distribution(weights, m, 0, distribution, best_distribution, best_deviation, ideal_weight);
    cout << "Камни:" << " ";
    for (int translator_item1 : weights)
    {
        cout << translator_item1 << " ";
    }
    cout << endl;
    cout << "Количество куч:" << " " << m << endl;
    cout << "Идеальный вес:" << " " << ideal_weight << endl;
    cout << "Лучшее распределение:" << endl;
    vector<int> pile_weights;
    for (int j = 0; j < m; j++)
    {
        pile_weights.push_back(0);
    }
    for (int i = 0; i < weights.size(); i++)
    {
        int pile = best_distribution[i];
        pile_weights[pile] += weights[i];
        cout << "Камень" << " " << weights[i] << " " << "-> куча" << " " << pile + 1 << endl;
    }
    for (int j = 0; j < m; j++)
    {
        double deviation = pile_weights[j] - ideal_weight;
        if (deviation < 0.0)
        {
            deviation = -deviation;
        }
        cout << "Вес кучи" << " " << j + 1 << " " << ":" << " " << pile_weights[j] << endl;
        cout << "Отклонение кучи" << " " << j + 1 << " " << ":" << " " << deviation << endl;
    }
    cout << "Суммарное отклонение:" << " " << best_deviation[0] << endl;
    return 0;
}
